void on_pushButton_voxpathSelect_clicked();
#ifndef VOX3DFORM_H
#define VOX3DFORM_H

#include <QWidget>

//#include "qobj3dreader.h" //openGL基礎表示のため
//#include "voxRead_makeGLdata.h" //voxファイル形式から,openGL描画形式のデータへの整形
#include "CommonSubClass.h" //カスタマイズしたコンボボックス部品

#include <QMainWindow>
#include <QFileDialog>
#include <QDir>
#include <QStandardPaths>
#include <QSettings>
#include <QCloseEvent>
#include <QDebug>
#include <QHBoxLayout>

//-start- Vox3DFormSub02readVoxMakeGL.cpp
#include <QObject>
#include <QVector>
#include <QVector3D>
#include <QVector2D>
#include <QFile>
#include <QRegularExpression>
#include <QDebug>
#include <QString>
#include <QStringList>
#include <QMessageBox>
#include <QDateTime>

#include <QOpenGLWidget>
#include <QOpenGLFunctions>
#include <QOpenGLBuffer>
#include <QOpenGLShaderProgram>
#include <QOpenGLWindow>
#include <QOpenGLVertexArrayObject>

#include <QOpenGLVertexArrayObject>
#include <QOpenGLVertexArrayObject>
#include <QMouseEvent>
#include <QMouseEventTransition>
#include <QOpenGLShader>
#include <QtOpenGL/QtOpenGL>
#include <QVector3D>
#include <QArrayData>
#include <gl/GL.h>
#include <gl/GL.h>
#include <math.h>
#include <QMatrix4x4>
#include <QScopedPointer>
#include <QElapsedTimer>
//#include <mainwindow.h>
//#inlude  <ui_mainwindow.h>
//#include <vertex.h>
#include <QTextCodec>
// For Japanese
# define TR(s) (QString::fromLocal8Bit(s))
#include <QFile> //kuroda
#include <QFileInfo> //kuroda
#include <tuple> //kuroda 2021.06.xx-01 //2つ以上の帰り値を返すため　std::tuple, std::forward_as_tuple, std::tie で使用する
#include <QHash>
#include <QMultiHash>
//-end- Vox3DFormSub02readVoxMakeGL.cpp

//-start- for-vox
#include <math.h>
//-end- for-vox

struct QOpenGLTriangle3D_vox
{
    QVector3D p1;
    QVector3D p2;
    QVector3D p3;
    QVector3D p1Normal;
    QVector3D p2Normal;
    QVector3D p3Normal;
    QVector2D p1UV;
    QVector2D p2UV;
    QVector2D p3UV;

    //-start- for-vox
    QVector3D color;
    int matnum;
    //-end-
};

//-end- Vox3DFormSub02readVoxMakeGL.cpp


namespace Ui {
class Vox3DForm;
}

class Vox3DForm : public QWidget
{
    Q_OBJECT

public:
    explicit Vox3DForm(QWidget *parent = nullptr);
    ~Vox3DForm();

    QVector<QOpenGLTriangle3D_vox> g_vox_triangles;

    //-start- Vox3DFormSub02readVoxMakeGL.cpp
    void func_01main_GL_makeGL3DfromVox(QVector<QOpenGLTriangle3D_vox> &triangles, QString in_voxfilepath);
    void func_GL_make_getPointOfMesh(QVector<QOpenGLTriangle3D_vox> &triangles, QVector<QVector3D> in_voxXYZVec, QStringList in_voxSurfaceStrList, QVector<QVector3D> in_voxColors, QVector<int>in_voxMatnumVec); //voxファイルからの取得情報を、openGL描画形式のデータに置き換える
    void func_vox_get_voxGraffic(QString in_voxfilepath); //voxファイルから、座標とマテリアル情報を取得する　1点ごと
    void zDEBUG_vox_get_voxGraffic_DEBUG01(QString in_voxfilepath); //[DEBUG] 例：　正方形1つ表示 正常表示される.
    void zDEBUG_vox_get_voxGraffic_DEBUG02(QString in_voxfilepath); //[DEBUG] 例：　閉じてない面だけの3D形状　→　裏に色が付かない.　これから対処する　or voxは全て閉じているはずなので問題にならないかもしれない。

    QVector<QVector3D> g_voxXYZVec; //vox情報　GL座標情報(triangle)にも使用する
    QVector<QVector3D> g_voxColorVec;//vox情報　GL座標情報(triangle)にも使用する
    QVector<int> g_voxMatnumVec; //vox情報　マテリアル番号  // GL座標情報(triangle)への代入はなし
    QStringList g_voxSurfaceStrList; //vox→3Dにした場合の、面の向き(Front, Back, Right, Left, Top, Bottom)  // GL座標情報(triangle)への代入はなし
    QMultiHash<int, int> g_voxMatToPnumHash; //マテリアル番号(matnum) と g_voxXYZvecインデックス番号(pnum)の紐づけ。　GUI操作色切替え・表示切替えのため。　pnum = positionNumber=インデックス番号の意味。
    //QVector<QVector3D> g_GLColors;

    QVector3D func_GL_defineColor(int input_num);
    QVector3D func_GL_defineColor_nameToRGBvec(QString input_colorname); //Redなどの名前から QVector(1,0,0) を返り値とする

    //-start- opengl_myk miwidget.cppから流用
    //voxファイル読み込み用途
    //QStringList g_DrawMeshXYZList; //[DEBUG]用途　使わない。
    //dragFilePathList.clear();　//　使わない。
    QString g_voxfilePath;

    //メッシュサイズ
    float meshsize;
    float meshsize_x;
    float meshsize_y;
    float meshsize_z;

    //総メッシュ数
    int nx,ny,nz;
    unsigned int meshAll;
    void func_vox_getMateNumOfMesh(QString in_voxfilepath); //voxファイルのヘッダー情報読み込み + voxファイルを読み込んで、メッシュごとにマテリアルNo.を割り当てる
    void func_vox_GLadd_checkMateNumOfAdjoinMesh(); //openGL描画用の情報を入れる。　(流用元checkMateNumOfAdjoinMeshでは、通常座標としての記録のみだったが、処理内容変更。）

    QVector<int> mateNoOfMesh;
    //メッシュごとのマテリアルNo
    unsigned int meshNo = 0;

    //メッシュNo. および面情報
    QMultiMap<int,unsigned int> DrawMesh;
    QMultiHash<unsigned int, int> DrawSurface;

    //voxに登録されている全マテリアルのNoと名前
    QList<int> mateNoList;
    QStringList mateNameList;
    //-end- Vox3DFormSub02readVoxMakeGL.cpp

public slots:
    //-start- Vox3DFormSub02readVoxMakeGL.cpp
    int fileWrteForWindows(QString WriteFilePath, QString WriteMode, QStringList msgList);
    QStringList readTextFileAll(QString fileName);
    //-end- Vox3DFormSub02readVoxMakeGL.cpp

    void func_slot_mousewheelZoom(float in_modelScale); //for vox
    void func_slot_mouseRotate(float in_rotateAngleY, float in_rotateAngleZ); //マウスドラッグで、図形回転。 GUI図形平行移動チェックボックスOFFの場合。
    void func_slot_mouseDrag02(int in_mouseMoveX, int in_mouseMoveY); //マウスドラッグで、図形平行移動。 GUI図形平行移動チェックボックスONの場合。

private slots:
    void on_persVerticalAngleSpin_valueChanged(double arg1);

    void on_persNearSpin_valueChanged(double arg1);

    void on_persFarSpin_valueChanged(double arg1);

    void on_lookEyeXSpin_valueChanged(double arg1);

    void on_lookEyeYSpin_valueChanged(double arg1);

    void on_lookEyeZSpin_valueChanged(double arg1);

    void on_lookCenterXSpin_valueChanged(double arg1);

    void on_lookCenterYSpin_valueChanged(double arg1);

    void on_lookCenterZSpin_valueChanged(double arg1);

    void on_lookUpXSpin_valueChanged(double arg1);

    void on_lookUpYSpin_valueChanged(double arg1);

    void on_lookUpZSpin_valueChanged(double arg1);

    void on_scaleSpin_valueChanged(double arg1);

    void on_translateXSpin_valueChanged(double arg1);

    void on_translateYSpin_valueChanged(double arg1);

    void on_translateZSpin_valueChanged(double arg1);

    void on_rotateAngleSpin_valueChanged(double arg1);

    void on_rotateXSpin_valueChanged(double arg1);

    void on_rotateYSpin_valueChanged(double arg1);

    void on_rotateZSpin_valueChanged(double arg1);

    void on_lightPosXSpin_valueChanged(double arg1);

    void on_lightPosYSpin_valueChanged(double arg1);

    void on_lightPosZSpin_valueChanged(double arg1);

    void on_actionAbout_Qt_triggered();

    void on_action_Open_triggered();

    void on_actionExit_triggered();

    void on_persVerticalAngleSlider_valueChanged(int value);

    void on_persNearSlider_valueChanged(int value);

    void on_persFarSlider_valueChanged(int value);

    void on_lightKd1Spin_valueChanged(double arg1);

    void on_lightKd2Spin_valueChanged(double arg1);

    void on_lightKd3Spin_valueChanged(double arg1);

    void on_lightLd1Spin_valueChanged(double arg1);

    void on_lightLd2Spin_valueChanged(double arg1);

    void on_lightLd3Spin_valueChanged(double arg1);

    void on_textureFileEdit_returnPressed();

    void on_browseTextureBtn_pressed();
    void on_pushButton_matTableToGL_clicked();

    void on_rotateAngleSlider_valueChanged(int value);
    void on_lineEdit_rotateAngleZ_editingFinished();

    //-start- for-vox
    void on_DEBUG01_pushButton_clicked();
    void on_checkBox_acolor_stateChanged(int arg1);
    void on_pushButton_voxpathSelect_clicked();
    void on_pushButton_voxpathLoad_clicked();
    void func_tableMateriaRedrawSlot(int); //ユーザー操作で、チェックボックス変更を, simNameテーブルに記録する
    void func_tableMaterialColorSlotChanged(int); //ユーザー操作で、マテリアル色選コンボボックスが変わった場合の処理
    void on_lineEdit_rotateAngleY_editingFinished();
    void on_pushButton_viewAllOn_clicked();
    void on_pushButton_viewAllOff_clicked();
    void on_checkBox_voxshift_stateChanged(int arg1);
    //-end- for-vox

private:
    Ui::Vox3DForm *ui;

    void closeEvent(QCloseEvent *bar);

    void updateEverything();

    //-start- for-vox
    void func_setGUIstartup(); //スタート時のGUI設定
    void func_tableMaterialDefaultSet(QStringList materialLineList); //materialテーブルのセット。マテリアルごとに表示・非表示, 色の変更などの用途。
    void func_tableMaterialDefaultSet_matnameToColorCombo(); //materialテーブルのセット。特定のマテリアルの場合、色設定コンボボックスを特定の色にセットする。
    QStringList func_getMaterialfromVoxPath(QString in_filepath); //voxfile からマテリアル行のみ取得する。

    //使わない//int g_rowChecked_material(); //テーブル上のチェックボックスのsignal&slotアクション時に使う変数
    QStringList func_tableMaterial_gval();//QStringList func_gval_table_material();  //GL描画処理用の別cpp への値渡しのため、グローバル変数を更新する。
    void func_tableMaterialColorAdd(int row); //マテリアルテーブル　色選択コンボボックスの設定。
    int g_flag_slotMatColorCombo; //マテリアルコンボの値変更時にスロット処理させる:1 or させない:0。（ユーザー操作の時だけスロット処理したい。自動設定のとき（自動=初期設定の時など）はスロット処理したくない）
    int g_flag_slotMatView; //表示・非表示切替え　スロット処理させる:1 or させない:0。（ユーザー操作の時だけスロット処理したい。自動設定のとき（自動=初期設定の時など）はスロット処理したくない）
    void func_tableMaterialToGL(); //for-vox  GL描画更新：ユーザーによるGUI操作された時点で、材質ごとの表示切替え・色切替え
    QHash<int, QVector3D> func_GL_defineColor_byTableMaterial(); //マテリアルテーブルからハッシュ作成する。　マテリアル番号と色番号 QVector3D(R, G, B) を紐づける

};

#endif // VOX3DFORM_H
