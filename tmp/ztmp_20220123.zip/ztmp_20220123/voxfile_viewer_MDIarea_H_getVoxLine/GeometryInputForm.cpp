#include "GeometryInputForm.h"
#include "ui_GeometryInputForm.h"

GeometryInputForm::GeometryInputForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::GeometryInputForm)
{
    ui->setupUi(this);
    this->setWindowTitle("2Dviewer");
}

GeometryInputForm::~GeometryInputForm()
{
    delete ui;
}

void GeometryInputForm::func_slot_2D_acceptVoxpath(QString inStr)
{
    qDebug() << "[DEBUG]Geo.cpp-func_slot_2D_acceptVoxpath";
    ui->vox_path_lineEdit->setText("instr=" + inStr);
}
