#include "Zsub2Form.h"
#include "ui_Zsub2Form.h"

void Zsub2Form::closeEvent(QCloseEvent *bar){ //×ボタンが押されても、画面を閉じないようにする
    bar->ignore();
}

Zsub2Form::Zsub2Form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Zsub2Form)
{
    ui->setupUi(this);
}

Zsub2Form::~Zsub2Form()
{
    delete ui;
}

//---------------------------------------------------------------------------------------------------------------------
//旧 2021.10.11-v1  動くが実データ遅い　void Vox3DForm::zDEBUG_func_tableMaterialToGL //for-vox  ユーザーによるGUI操作で、材質ごとの表示切替え・色切替え
//{
    //形状の表示・非表示　色変更の反映=ok
    //-start-色変更の例 動作するけど、2回ボタン押して初めて反映される。。　これから修正する。
    //-start- 非表示の例
//    QVector<QOpenGLTriangle3D_vox> tmp_vox_triangles;
//    tmp_vox_triangles = g_vox_triangles;
//    for(int i = tmp_vox_triangles.count()-1; i>=0; i--){
//        //　削除後インデックス番号に影響しないように、後ろから処理する
//        //qDebug() << QString("\n\n[DEBUG]Vox3DForm.cpp-on_DEBUG01_pushButton_clicked() before matnum=%1 color=%2,%3,%4").arg(QString::number(tmp_vox_triangles.at(i).matnum), QString::number(tmp_vox_triangles.at(i).color.x()), QString::number(tmp_vox_triangles.at(i).color.y()), QString::number(tmp_vox_triangles.at(i).color.z()));
//        if(tmp_vox_triangles.at(i).matnum == 13){
//            tmp_vox_triangles.remove(i);
//        }
//    }
//    updateEverything();
//    ui->obj3dViewer->func_vox_setTriangles(tmp_vox_triangles);

    //-start-色変更の例=ok
    //QVector<QOpenGLTriangle3D_vox> tmp_vox_triangles;
//    tmp_vox_triangles = g_vox_triangles;
//    for(int i=0; i < g_vox_triangles.count(); i++){
//        qDebug() << QString("\n\n[DEBUG]Vox3DForm.cpp-on_DEBUG01_pushButton_clicked() before matnum=%1 color=%2,%3,%4").arg(QString::number(tmp_vox_triangles.at(i).matnum), QString::number(tmp_vox_triangles.at(i).color.x()), QString::number(tmp_vox_triangles.at(i).color.y()), QString::number(tmp_vox_triangles.at(i).color.z()));
//        if(tmp_vox_triangles.at(i).matnum == 12){

//            QOpenGLTriangle3D_vox one_tri = tmp_vox_triangles.at(i);
//            one_tri.color = QVector3D(1, 0, 0); //赤
//            tmp_vox_triangles.replace(i, one_tri);
//        }
//    }
//    for(int i=0; i < g_vox_triangles.count(); i++){
//        qDebug() << QString("\n\n[DEBUG]Vox3DForm.cpp-on_DEBUG01_pushButton_clicked() after matnum=%1 color=%2,%3,%4").arg(QString::number(tmp_vox_triangles.at(i).matnum), QString::number(tmp_vox_triangles.at(i).color.x()), QString::number(tmp_vox_triangles.at(i).color.y()), QString::number(tmp_vox_triangles.at(i).color.z()));
//    }
//    updateEverything();
//    ui->obj3dViewer->func_vox_setTriangles(tmp_vox_triangles);
//    qDebug() << "\n\n[DEBUG]Vox3DForm.cpp-on_DEBUG01_pushButton_clicked() color-change End";
    //-end- 色変更の例
//}



//---------------------------------------------------------------------------------------------------------------------
//旧 2021.10.11-v2-NG void Vox3DForm::zNG_func_tableMaterialToGL() //for-vox  GL描画更新：ユーザーによるGUI操作された時点で、材質ごとの表示切替え・色切替え
//{
//    qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() start-time=" + QDateTime::currentDateTime().toString("hh:mm:ss");;

//    QStringList uiMatTableList = func_tableMaterial_gval(); //openGL描画処理の別cppに値渡しするため、グローバル変数更新
//    QList<int> nonViewMatList;
//    QVector<QVector3D> colorRGBvec;
//    QHash<int ,QVector3D> colorNameToRGBhash;
//    for(int i=0; i < uiMatTableList.count(); i++){
//        //qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() i=" << QString::number(i) << " tableMaterial_gval=" << uiMatTableList.at(i);
//        QStringList tmpStrList =  uiMatTableList.at(i).split(",");
//        int flag_chk = tmpStrList.at(0).toInt();
//        int matnum = tmpStrList.at(1).toInt();
//        QString colorname = tmpStrList.at(3);

//        if(flag_chk == 0 ){ nonViewMatList << matnum; }

//        QVector3D colorRGB = func_GL_defineColor_nameToRGBvec(colorname);
//        colorNameToRGBhash[matnum] = colorRGB;
//    }

//    QString tmpStr = "";
//    for(int i=0; i<nonViewMatList.size(); i++){ tmpStr += nonViewMatList.at(i); }
//    //qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() nonViewMatList=" << tmpStr;

//    foreach(int key, colorNameToRGBhash.keys()){
//        //qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() key" << QString::number(key) << " RGBcolor:x=" << QString::number(colorNameToRGBhash[key].x()) << " y=" << QString::number(colorNameToRGBhash[key].y()) << " z=" << QString::number(colorNameToRGBhash[key].z());
//    }

//    QVector<QOpenGLTriangle3D_vox> tmp_vox_triangles;
//    tmp_vox_triangles = g_vox_triangles;
//    for(int i = tmp_vox_triangles.count()-1; i>=0; i--){  // 非表示=削除処理の場合,インデックス番号に影響しないように、後ろから処理する
//        //qDebug() << QString("[DEBUG]01 Vox3DForm.cpp-func_tableMaterialToGL() i=%1 triangle_matnum=%2").arg(QString::number(i), QString::number(tmp_vox_triangles.at(i).matnum));

//        int matnum = tmp_vox_triangles.at(i).matnum;

//        // マテリアルテーブルの通りの色にする　...　全triangle変更なので遅くなるかも? チェックされたものだけ取得して対象にした方が良い？
//        if( colorNameToRGBhash.contains(matnum)){
//            //qDebug() << "[DEBUG]02 Vox3DForm.cpp-func_tableMaterialToGL()";
//            QVector3D colorRGB = colorNameToRGBhash[matnum];
//            QOpenGLTriangle3D_vox one_tri = tmp_vox_triangles.at(i);
//            //[DEBUG]// one_tri.color = QVector3D(1, 0, 0); //赤
//            one_tri.color = colorRGB;
//            tmp_vox_triangles.replace(i, one_tri);
//        }
//        //qDebug() << "[DEBUG]03 Vox3DForm.cpp-func_tableMaterialToGL()";

//        // マテリアルテーブルで表示チェックボックスOFFなら、非表示にする
//        //qDebug() << QString("\n\n[DEBUG]Vox3DForm.cpp-on_DEBUG01_pushButton_clicked() before matnum=%1 color=%2,%3,%4").arg(QString::number(tmp_vox_triangles.at(i).matnum), QString::number(tmp_vox_triangles.at(i).color.x()), QString::number(tmp_vox_triangles.at(i).color.y()), QString::number(tmp_vox_triangles.at(i).color.z()));
//        //if(tmp_vox_triangles.at(i).matnum == 13){
//        if(nonViewMatList.indexOf(tmp_vox_triangles.at(i).matnum) > -1 ){
//            //qDebug() << "[DEBUG]04 Vox3DForm.cpp-func_tableMaterialToGL()";
//            tmp_vox_triangles.remove(i);
//        }
//        //qDebug() << "[DEBUG]05 Vox3DForm.cpp-func_tableMaterialToGL()";
//    }
//    qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() -end- data-change time=" + QDateTime::currentDateTime().toString("hh:mm:ss");
//    qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() -start- openGL-update time=" + QDateTime::currentDateTime().toString("hh:mm:ss");
//    updateEverything();
//    ui->obj3dViewer->func_vox_setTriangles(tmp_vox_triangles);
//    qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() -end- openGL-update time=" + QDateTime::currentDateTime().toString("hh:mm:ss");
//}

/*
//旧 2021.10.11-v3  NG 削除で落ちる
void Vox3DForm::func_tableMaterialToGL() //for-vox  GL描画更新：ユーザーによるGUI操作された時点で、材質ごとの表示切替え・色切替え
{

        QStringList uiMatTableList = func_tableMaterial_gval(); //openGL描画処理の別cppに値渡しするため、グローバル変数更新
        QList<int> nonViewMatList;
        QVector<QVector3D> colorRGBvec;
        QHash<int ,QVector3D> colorNameToRGBhash;

        //voxファイル読み込み済のデータは変えずに、tmp_vox_triangles に描画変更内容を入れて反映させる
        QVector<QOpenGLTriangle3D_vox> tmp_vox_triangles = g_vox_triangles;

        // 色切替え　マテリアルテーブルで指定された色にする
        qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() -start- color-change time=" + QDateTime::currentDateTime().toString("hh:mm:ss");
        for(int row=0; row < uiMatTableList.count(); row++){
            //qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() row=" << QString::number(row) << " tableMaterial_gval=" << uiMatTableList.at(row);
            QStringList tmpStrList =  uiMatTableList.at(row).split(",");
            int flag_chk = tmpStrList.at(0).toInt();
            int matnum = tmpStrList.at(1).toInt();
            QString colorname = tmpStrList.at(3);


            QVector3D colorRGB = func_GL_defineColor_nameToRGBvec(colorname);
            colorNameToRGBhash[matnum] = colorRGB;
            if(flag_chk != 0 && g_voxMatToPnumHash.contains(matnum)){
                QList<int> tmp_pnumList = g_voxMatToPnumHash.values(matnum);  //g_voxXYZListのインデックス番号

                for(int i = 0 ; i < tmp_pnumList.size(); i++){
                    int pnum = tmp_pnumList.at(i);

                    //色切替え　マテリアルテーブルで指定された色にする
                    QOpenGLTriangle3D_vox one_tri;
                    one_tri = tmp_vox_triangles.at(pnum*2); //1つ目の三角形 ※平面1つ=triangel2つで構成される
                    //[DEBUG]// one_tri.color = QVector3D(1, 0, 0); //赤
                    one_tri.color = colorRGB;
                    tmp_vox_triangles.replace(pnum*2, one_tri);

                    one_tri = tmp_vox_triangles.at((pnum*2) + 1); //2つ目の三角形 ※平面1つ=triangel2つで構成される
                    //[DEBUG]// one_tri.color = QVe(ctor3D(1, 0, 0); //赤
                    one_tri.color = colorRGB;
                    tmp_vox_triangles.replace((pnum*2) + 1, one_tri);
                }
            }
        }
        //-end- for(int row=0; row < uiMatTableList.count(); row++)
        qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() -end- color-change time=" + QDateTime::currentDateTime().toString("hh:mm:ss");

        //非表示切替え 落ちる。。これから修正 多分　削除によるずれが生じている
//        qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() -start- color-change time=" + QDateTime::currentDateTime().toString("hh:mm:ss");
//        for(int row=0; row < uiMatTableList.count(); row++){
//            //qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() row=" << QString::number(row) << " tableMaterial_gval=" << uiMatTableList.at(row);
//            QStringList tmpStrList =  uiMatTableList.at(row).split(",");
//            int flag_chk = tmpStrList.at(0).toInt();
//            int matnum = tmpStrList.at(1).toInt();
//            QString colorname = tmpStrList.at(3);

//            if(flag_chk == 0 && g_voxMatToPnumHash.contains(matnum)){
//                QList<int> tmp_pnumList = g_voxMatToPnumHash.values(matnum);  //g_voxXYZListのインデックス番号

//                for(int i = 0 ; i < tmp_pnumList.size(); i++){
//                    int pnum = tmp_pnumList.at(i);
//                    tmp_vox_triangles.remove(pnum*2);
//                    tmp_vox_triangles.remove((pnum*2)+1);
//                }
//            }
//        }
//        qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() -end- color-change time=" + QDateTime::currentDateTime().toString("hh:mm:ss");


        qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() -start- openGL-update time=" + QDateTime::currentDateTime().toString("hh:mm:ss");
        updateEverything();
        ui->obj3dViewer->func_vox_setTriangles(tmp_vox_triangles);
        qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() -end- openGL-update time=" + QDateTime::currentDateTime().toString("hh:mm:ss");


}
*/
