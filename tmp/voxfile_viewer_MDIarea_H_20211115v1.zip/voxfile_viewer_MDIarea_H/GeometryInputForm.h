#ifndef GEOMETRYINPUTFORM_H
#define GEOMETRYINPUTFORM_H

#include <QWidget>

namespace Ui {
class GeometryInputForm;
}

class GeometryInputForm : public QWidget
{
    Q_OBJECT

public:
    explicit GeometryInputForm(QWidget *parent = nullptr);
    ~GeometryInputForm();

private:
    Ui::GeometryInputForm *ui;
};

#endif // GEOMETRYINPUTFORM_H
