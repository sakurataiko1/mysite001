#include "MainWindow.h"
#include "ui_MainWindow.h"

#include "Vox3DForm.h"
//#include "Zsub2Form.h"
#include "GeometryInputForm.h"

#include <QMdiSubWindow>
#include <QFileDialog>
#include <QMessageBox>
#include <QTextStream>
#include <QFile>
#include <QDir>
#include <QFileInfo>
#include <QDateTime>
#include <QSplashScreen>
#include <QDebug>
//#include <QtScript>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //mVox3DForm = new Vox3DForm(this); //文法エラーになることがあり、コメントアウトした
    // ↑シグナルスロットのconnectで使う
    //　↑ヘッダーの　explicit Vox3DForm(QWidget *parent = nullptr);  nullptrから0に書き換えれば文法エラーは解消するが、openGLウィジェット部がおかしくなってしまう。
    // ↑解決策探し中
    SubWindowVox3DForm = ui->mdiArea->addSubWindow(new Vox3DForm);
    SubWindowVox3DForm->setGeometry(100, 20, 750, 580);
    SubWindowVox3DForm->raise();

    //mZsub2Form = new Zsub2Form(this);　//文法エラーになることがあり、コメントアウトした
    //SubWindowZsub2Form = ui->mdiArea->addSubWindow(new Zsub2Form);
    //SubWindowZsub2Form->setGeometry(900, 40, 800, 880);
    //SubWindowZsub2Form->raise();

    //mVox3DForm = new GeometryInputForm(this); //文法エラーになることがあり、コメントアウトした
    SubWindowGeometryInputForm = ui->mdiArea->addSubWindow(new GeometryInputForm);
    SubWindowGeometryInputForm->setGeometry(900, 40, 800, 880);
    SubWindowGeometryInputForm->raise();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionExit_triggered() {//プログラム終了して、GUIを閉じる。
    exit(0);
}

void MainWindow::on_action3Dviewer_triggered() {//3Dviewerを前面に表示する
    SubWindowVox3DForm->setVisible(true);
    SubWindowVox3DForm->raise();
    SubWindowVox3DForm->setWindowState(Qt::WindowActive);
}

void MainWindow::on_action2Dviewer_triggered() {//3Dviewerを前面に表示する
    qDebug() << "[DEBUG]01 on_action2Dviewer_triggered";
    SubWindowGeometryInputForm->setVisible(true);
    SubWindowGeometryInputForm->raise();
    SubWindowGeometryInputForm->setWindowState(Qt::WindowActive);
}
