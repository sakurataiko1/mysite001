#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QFile>
#include <QFileInfo>
#include <QFileDialog>
#include <QTextStream>
#include <QDebug>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->pushButton_outVoxSelectPath->setVisible(false); //まだ機能していない
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_outVoxRun_clicked()
{
    func_makevoxfile();
}

void MainWindow::func_makevoxfile() {
    int nx = ui->lineEdit_voxsizeX->text().toInt();
    int ny = ui->lineEdit_voxsizeY->text().toInt();
    int nz = ui->lineEdit_voxsizeZ->text().toInt();

    //GUI textEditの1行内容　マテリアル番号　マテリアル名 始点X Y Z メッシュの数 sizeX sizeY sizeZ
    QStringList lineAllList = ui->textEdit_vox->toPlainText().split("\n");
    QStringList matnumList, matnameList;
    for(int row=0; row<lineAllList.count(); row++){
        QStringList  onelineList = lineAllList.at(row).split(" ");
        matnumList << onelineList.at(0);
        matnameList << onelineList.at(1);
    }

    //3次元 配列用意する
    int ***aryVox;
    aryVox= new int**[nz];
    for(int z=0; z<nz; z++){
        aryVox[z] = new int*[ny];
        for(int y=0; y<ny; y++){
            aryVox[z][y] = new int[nx](); //()でデータがないときは0で全部初期化する
        }
    }

    //vox図形データの入力
    for(int row=0; row < lineAllList.count(); row++ ){
        if(lineAllList.at(row) == "" || lineAllList.at(row).isEmpty()){ continue; } //処理スキップ　次の行へ
        QStringList lineList = lineAllList.at(row).split(" ");
        int matnum = lineList.at(0).toInt();
        int X1 = lineList.at(2).toInt();
        int Y1 = lineList.at(3).toInt();
        int Z1 = lineList.at(4).toInt();
        int X2 = lineList.at(5).toInt();
        int Y2 = lineList.at(6).toInt();
        int Z2 = lineList.at(7).toInt();
        for(int z=Z1; z<=Z2; z++){
            for(int y=Y1; y<=Y2; y++){
                for(int x=X1; x<=X2; x++){
                    if(x<nx && y<ny && z<nz){
                         aryVox[z][y][x] = matnum;
                    }
                }
            }
        }
    }

    //-start- [DEBUG]DEBUG表示用
    qDebug() << "[DEBUG]func_makeVoxLine() aryVox[z, y, x]:";
    for(int k=nz-1; k>=0; k--){ //見やすいように下から
        for(int j=ny-1; j>=0; j--){ //見やすいように前から
            QString tmpstr = "";
            for(int i=0; i<nx; i++){ //xはそのまま　左から右の並び順
                tmpstr += " " + QString::number(aryVox[k][j][i]);
            }
            qDebug() << tmpstr;
        }
    }
    //-end- [DEBUG]DEBUG表示用

    //-------------------------------
    //voxfile書き込み
    QStringList outList;
    outList << "Version 2.1";
    outList << "1	precision";
    outList << QString::number(ui->lineEdit_meshsize->text().toInt() * 0.001) + "	unitlength";
    outList << "0\tAir";
    //outList << "11	TEST11";
    //outList << "12	TEST12";
    for(int i=0; i < matnameList.count(); i++){
        outList << matnumList.at(i) + "\t" + matnameList.at(i);
    }
    outList << "CellData";
    //outList << "10 x 5 x 6";
    outList << QString::number(nx) + " x " + QString::number(ny) + " x " + QString::number(nz);
    //voxfile書き込み -vox図形データ

    for(int z=0; z<nz; z++){
        for(int y=0; y<ny; y++){
            //int countmaterial=0;
            //QString onelineStr = "";
            //int x = 0;
            //while(x < nx){
            //    int tmpvalue = aryVox[z][y][x1];
            //    onelineStr = QString::number(tmpvalue) + " "; //マテリアル番号
            //    for(x=x; x<nx; x++){
            //        int tmpint = aryVox[z][y][x];
            //        //x1 = x;
            //        if(aryVox[z][y][x] == tmpvalue){
            //            countmaterial++;
            //        } else {
            //            break;
            //        }
            //    }
            //    onelineStr = QString::number(countmaterial) + " "; //マテリアル連続数
            //    countmaterial = 0;
            //}
            //outList << onelineStr; //1行分終了

            int countmaterial=0;
            QString onelineStr = "";
            for(int x=0; x<nx; x++){
                int DEBUG_int1 = aryVox[z][y][x];
                int DEBUG_int2 = aryVox[z][y][x-1];
                if(x == 0){
                    countmaterial++;
                } else if(x == nx-1){
                    if(aryVox[z][y][x] == aryVox[z][y][x-1]){
                        countmaterial++;
                        onelineStr += QString::number(aryVox[z][y][x-1]) + " " + QString::number(countmaterial) + " ";
                    } else {
                        onelineStr += QString::number(aryVox[z][y][x-1]) + " " + QString::number(countmaterial) + " ";
                        onelineStr += QString::number(aryVox[z][y][x]) + " 1 ";
                    }
                } else if(x > 0){
                    if(aryVox[z][y][x] == aryVox[z][y][x-1]){
                        countmaterial++;
                    } else {
                        onelineStr += QString::number(aryVox[z][y][x-1]) + " " + QString::number(countmaterial) + " ";
                        countmaterial = 1;
                    }
                }
            }
            outList << onelineStr; //1行分終了

        }
    }

    //出力ファイルに書き込み
    QString WriteFilePath = ui->lineEdit_outVoxPath->text();
    QString WriteMode = "WriteOnly";
    fileWriteForWindows(WriteFilePath, WriteMode, outList);
    QMessageBox::information(this, "notice", "save file.\n" + WriteFilePath);

    //メモリ解放
    for(int z=0; z<nz; z++){
        for(int y=0; y<ny; y++){
            delete[] aryVox[z][y] ;
        }
        delete[] aryVox[z];
    }
    delete[] aryVox;
}


void MainWindow::on_pushButton_outVoxSelectPath_clicked()
{
    //ユーザーによるvoxファイル選択-------------------------------------------------------------------------
//    QString loadfileName = "";
//    QStringList tmpStringList;
//    QString loadfileNameBefore;
//    QString beforefilename , beforefilepath;
//    QString tmpDirPath;

//    //既にloadされているファイルがある場合はそのファイルがあるフォルダをファイル選択ダイアログの起点フォルダとする
//    tmpDirPath =  "Desktop";
//    if(ui->lineEdit_voxpath->text() != ""){
//        tmpDirPath = QFileInfo(ui->lineEdit_voxpath->text()).absolutePath();
//    }
//    //ファイル読込み
//    //loadfileName = QFileDialog::getOpenFileName(this, tr("Select file"), tmpDirPath, tr("text file (*.txt)"));
//    loadfileName = QFileDialog::getOpenFileName(this, tr("Select file"), tmpDirPath);
//    if(loadfileName.isEmpty() == 1 ){return;} // ファイル選択でキャンセルボタンが押されたら, そのまま終了。
//    ui->lineEdit_voxpath->setText(loadfileName);
}


//ファイル書き込み(windowsで使うファイル用)
int MainWindow::fileWriteForWindows(QString WriteFilePath, QString WriteMode, QStringList msgList)
{
     QFile file(WriteFilePath);
     if(WriteMode == "Append"){
         if(!file.open(QIODevice::Append| QIODevice::Text)){
             //QMessageBox::information(this, tr("Unable to openfile"), file.errorString()); //Qtフォームクラスでないため、QMessageBoxが使えない。。代わりにエラーの場合は -1 を返り値に渡す
             return(-1);
         }
     } else {
         if(!file.open(QIODevice::WriteOnly| QIODevice::Text)){
             //QMessageBox::information(this, tr("Unable to openfile"), file.errorString());　 //Qtフォームクラスでないため、QMessageBoxが使えない。。代わりにエラーの場合は -1 を返り値に渡す
             return(-1);
         }
     }

     QTextStream out(&file);
     for (int n=0; n<msgList.size(); n++){
         out << msgList.at(n) << endl;
     }
     file.close();
}



