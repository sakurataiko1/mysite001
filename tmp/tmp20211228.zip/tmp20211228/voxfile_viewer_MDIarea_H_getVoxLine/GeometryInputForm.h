#ifndef GEOMETRYINPUTFORM_H
#define GEOMETRYINPUTFORM_H

#include <QWidget>

#include <QDebug>

namespace Ui {
class GeometryInputForm;
}

class GeometryInputForm : public QWidget
{
    Q_OBJECT

public:
    explicit GeometryInputForm(QWidget *parent = nullptr);
    ~GeometryInputForm();

public slots:
    void func_slot_2D_acceptVoxpath(QString inStr);

private:
    Ui::GeometryInputForm *ui;
};

#endif // GEOMETRYINPUTFORM_H
