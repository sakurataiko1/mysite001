#ifndef SUBFORM01_H
#define SUBFORM01_H

#include <QWidget>

#include <QDebug>

namespace Ui {
class Subform01;
}

class Subform01 : public QWidget
{
    Q_OBJECT

public:
    explicit Subform01(QWidget *parent = nullptr);
    ~Subform01();

public slots:
    void func_subform01_DEBUG01();
    void func_slot_FM01_act01(QString inStr);
    void func_slot_FM01_act02(QString inStr);

private slots:
    void on_pushButton_clicked();


private:
    Ui::Subform01 *ui;
};

#endif // SUBFORM01_H
