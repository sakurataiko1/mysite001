#include "Subform01.h"
#include "ui_Subform01.h"

#include "Mainwindow.h" //extern変数取得のため

Subform01::Subform01(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Subform01)
{
    ui->setupUi(this);
    this->setWindowTitle("Subform01");
}

Subform01::~Subform01()
{
    delete ui;
}

void Subform01::on_pushButton_clicked()
{
    ui->lineEdit_SF_2->setText("server_name=" + SERVER_NAME);
}

void Subform01::func_subform01_DEBUG01(){
    qDebug() << "[DEBUG]01 Subform01.cpp-func_subform01_DEBUG01";
    ui->lineEdit_SF_2->setText("[DEBUG]02 Subform01.cpp-func_subform01_DEBUG01");
}

void Subform01::func_slot_FM01_act01(QString inStr)
{
    qDebug() << "[DEBUG]01 Subform01.cpp-func_slot_FM1_act01()";
    ui->lineEdit_SF_2->setText("act01 instr=" + inStr);
}

void Subform01::func_slot_FM01_act02(QString inStr)
{
    qDebug() << "[DEBUG]01 Subform01.cpp-func_slot_FM1_act02()";
    ui->lineEdit_SF_2->setText("act02 instr=" + inStr);
}
