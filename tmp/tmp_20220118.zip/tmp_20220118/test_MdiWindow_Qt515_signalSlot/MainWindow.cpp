#include "MainWindow.h"
#include "ui_MainWindow.h"

#include "Subform01.h"
#include "Subform02.h"

#include <QDebug>

QString SERVER_NAME="SERVER01";

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    mSubform01 = new Subform01(this);
    subwinSubform01 = ui->mdiArea->addSubWindow(mSubform01); //Signal&slot用途。　addSubWindow(new Subform01)の記述だと表示崩れがおきてしまう。
    subwinSubform01->setGeometry(100, 20, 300, 400);
    subwinSubform01->raise();

    mSubform02 = new Subform02(this);
    subwinSubform02 = ui->mdiArea->addSubWindow(mSubform02);
    subwinSubform02->setGeometry(300, 20, 400, 200);
    subwinSubform02->raise();

    SERVER_NAME="TEST01";

    connect(this, &MainWindow::sendtoFM01_act01, mSubform01, &Subform01::func_slot_FM01_act01 );
    connect( mSubform02, &Subform02::sendtoFM02_act01 , mSubform01, &Subform01::func_slot_FM01_act02 );

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    SERVER_NAME = ui->lineEdit_MW_1->text();
    qDebug() << "[DEBUG]MainWindow.cpp-on_pushButton_clicked() SERVER_NAME=" + SERVER_NAME;

    emit sendtoFM01_act01(ui->lineEdit_MW_1->text()); //シグナルスロット処理：connect経由 別ウィンドウで処理させる
}


void MainWindow::func_MW_DEBUG01(){
    qDebug() << "[DEBUG]01  MainWindow.cpp-func_DEBUG01()";
    ui->lineEdit_MW_2->setText("[DEBUG]02  MainWindow.cpp-func_DEBUG01()");
}
