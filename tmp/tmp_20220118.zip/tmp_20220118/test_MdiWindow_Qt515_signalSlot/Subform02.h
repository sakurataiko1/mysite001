#ifndef SUBFORM02_H
#define SUBFORM02_H

#include <QWidget>

#include <QDebug>

namespace Ui {
class Subform02;
}

class Subform02 : public QWidget
{
    Q_OBJECT

public:
    explicit Subform02(QWidget *parent = nullptr);
    ~Subform02();

signals:
    void sendtoFM02_act01(QString sendStr);

private slots:
    void on_pushButton_clicked();

private:
    Ui::Subform02 *ui;
};

#endif // SUBFORM02_H
