#ifndef SUBFORM01_H
#define SUBFORM01_H

#include <QWidget>

#include <QDebug>

namespace Ui {
class Subform01;
}

class Subform01 : public QWidget
{
    Q_OBJECT

public:
    explicit Subform01(QWidget *parent = nullptr);
    ~Subform01();

    Ui::Subform01 *ui; //他クラスからアクセスできるように publicに移動する

public slots:
     void on_pushButton_clicked();
     void func_slot_FM1_act01(QString inStr);

    void func_subform01_DEBUG01();

private slots:
    //void on_pushButton_clicked();  //他クラスからアクセスできるように publicに移動する

private:
    //Ui::Subform01 *ui; //他クラスからアクセスできるように publicに移動する
};

#endif // SUBFORM01_H
