#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include <QPointer>
#include <QMdiSubWindow>

extern QString SERVER_NAME;

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class Subform01; //MDIarea用途
class Subform02;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void func_MW_DEBUG01();

private slots:
    void on_pushButton_clicked();

signals:
    void sendtoFM1_act01(QString sendStr);

private:
    Ui::MainWindow *ui;

    QMdiSubWindow *subwinSubform01; //MDIarea用途
    QMdiSubWindow *subwinSubform02;

    QPointer<Subform01> mSubform01; //Signal&slot用途
};
#endif // MAINWINDOW_H
