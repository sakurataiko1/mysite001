#include "MainWindow.h"
#include "ui_MainWindow.h"

#include "Subform01.h" //for MDIwindow
#include "Subform02.h"

//#include "ui_Subform01.h" //お試し

#include <QDebug>

QString SERVER_NAME;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    mSubform01 = new Subform01(this);
    //NG//subwinSubform01 = ui->mdiArea->addSubWindow(new Subform01);
    subwinSubform01 = ui->mdiArea->addSubWindow(mSubform01);
    subwinSubform01->setGeometry(100, 20, 300, 400);
    subwinSubform01->raise();

    subwinSubform02 = ui->mdiArea->addSubWindow(new Subform02);
    subwinSubform02->setGeometry(300, 20, 400, 200);
    subwinSubform02->raise();

    SERVER_NAME="TEST01";



    connect(this, &MainWindow::sendtoFM1_act01, mSubform01, &Subform01::func_slot_FM1_act01 ); //書式エラー　：QObject::connect(MainWindow, Unknown): invalid nullptr parameter
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    SERVER_NAME = ui->lineEdit->text();
    qDebug() << "[DEBUG]MainWindow.cpp-on_pushButton_clicked() SERVER_NAME=" + SERVER_NAME;

    //mSubform01->func_subform01_DEBUG01();}
    //QMdiSubWindow *sw = qobject_cast<QMdiSubWindow *>(parentWidget());

    //Subform01 *mSubform01_tmp = new Subform01;
    //mSubform01->func_subform01_DEBUG01(); // slotにui操作入れていると落ちる
    //mSubform01->ui->lineEdit_2->setText("from MW.cpp-on_pushButton_clicked");　//落ちる。
    emit sendtoFM1_act01(ui->lineEdit->text());
}

void MainWindow::func_MW_DEBUG01(){
    qDebug() << "[DEBUG]01  MainWindow.cpp-func_DEBUG01()";
    ui->lineEdit_MW_2->setText("[DEBUG]02  MainWindow.cpp-func_DEBUG01()"); //落ちる
}
