#include "Subform01.h"
#include "ui_Subform01.h"

//#include "MainWindow.h" //extern変数取得のため

Subform01::Subform01(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Subform01)
{
    ui->setupUi(this);
    this->setWindowTitle("Subform01");
}

Subform01::~Subform01()
{
    delete ui;
}

void Subform01::on_pushButton_clicked()
{
    qDebug() << "[DEBUG]01 Subform01.cpp-on_pushButton_clicked ";
    //ui->lineEdit->setText("server_name=" + SERVER_NAME);

    //子供側からの呼び出し -OK-
    //MainWindow *mdiparent = qobject_cast<MainWindow*>(this->parentWidget());
    //mdiparent->func_MW_DEBUG01();
}

void Subform01::func_subform01_DEBUG01(){
    qDebug() << "[DEBUG]01 Subform01.cpp-func_subform01_DEBUG01";

    ui->lineEdit_2->setText("[DEBUG]02 Subform01.cpp-func_subform01_DEBUG01");
}

void Subform01::func_slot_FM1_act01(QString inStr)
{
    qDebug() << "[DEBUG]01 Subform01.cpp-func_slot_FM1_act01()";
    ui->lineEdit_2->setText("instr=" + inStr);
}
