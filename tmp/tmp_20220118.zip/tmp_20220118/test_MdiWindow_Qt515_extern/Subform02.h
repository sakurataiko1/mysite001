#ifndef SUBFORM02_H
#define SUBFORM02_H

#include <QWidget>

namespace Ui {
class Subform02;
}

class Subform02 : public QWidget
{
    Q_OBJECT

public:
    explicit Subform02(QWidget *parent = nullptr);
    ~Subform02();

private:
    Ui::Subform02 *ui;
};

#endif // SUBFORM02_H
