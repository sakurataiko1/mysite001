#include "Subform01.h"
#include "ui_Subform01.h"

#include "Mainwindow.h" //extern変数取得のため

Subform01::Subform01(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Subform01)
{
    ui->setupUi(this);
    this->setWindowTitle("Subform01");
}

Subform01::~Subform01()
{
    delete ui;
}

void Subform01::on_pushButton_clicked()
{
    ui->lineEdit->setText("server_name=" + SERVER_NAME);
}

