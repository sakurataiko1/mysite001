#include "MainWindow.h"
#include "ui_MainWindow.h"

#include "Subform01.h"
#include "Subform02.h"

#include <QDebug>

QString SERVER_NAME;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    subwinSubform01 = ui->mdiArea->addSubWindow(new Subform01);
    subwinSubform01->setGeometry(100, 20, 300, 400);
    subwinSubform01->raise();

    subwinSubform02 = ui->mdiArea->addSubWindow(new Subform02);
    subwinSubform02->setGeometry(300, 20, 400, 200);
    subwinSubform02->raise();

    SERVER_NAME="TEST01";
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    SERVER_NAME = ui->lineEdit->text();
    qDebug() << "[DEBUG]MainWindow.cpp-on_pushButton_clicked() SERVER_NAME=" + SERVER_NAME;
}

