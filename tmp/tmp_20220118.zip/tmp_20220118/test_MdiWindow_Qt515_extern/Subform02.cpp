#include "Subform02.h"
#include "ui_Subform02.h"

Subform02::Subform02(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Subform02)
{
    ui->setupUi(this);
    this->setWindowTitle("Subform02");
}

Subform02::~Subform02()
{
    delete ui;
}
