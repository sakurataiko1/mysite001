#ifndef SUBFORM01_H
#define SUBFORM01_H

#include <QWidget>

namespace Ui {
class Subform01;
}

class Subform01 : public QWidget
{
    Q_OBJECT

public:
    explicit Subform01(QWidget *parent = nullptr);
    ~Subform01();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Subform01 *ui;
};

#endif // SUBFORM01_H
