#include "Zsub2Form.h"
#include "ui_Zsub2Form.h"

void Zsub2Form::closeEvent(QCloseEvent *bar){ //×ボタンが押されても、画面を閉じないようにする
    bar->ignore();
}

Zsub2Form::Zsub2Form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Zsub2Form)
{
    ui->setupUi(this);
}

Zsub2Form::~Zsub2Form()
{
    delete ui;
}

//---------------------------------------------------------------------------------------------------------------------
//旧 2021.10.11-v1  動くが実データ遅い　void Vox3DForm::zDEBUG_func_tableMaterialToGL //for-vox  ユーザーによるGUI操作で、材質ごとの表示切替え・色切替え
//{
    //形状の表示・非表示　色変更の反映=ok
    //-start-色変更の例 動作するけど、2回ボタン押して初めて反映される。。　これから修正する。
    //-start- 非表示の例
//    QVector<QOpenGLTriangle3D_vox> tmp_vox_triangles;
//    tmp_vox_triangles = g_vox_triangles;
//    for(int i = tmp_vox_triangles.count()-1; i>=0; i--){
//        //　削除後インデックス番号に影響しないように、後ろから処理する
//        //qDebug() << QString("\n\n[DEBUG]Vox3DForm.cpp-on_DEBUG01_pushButton_clicked() before matnum=%1 color=%2,%3,%4").arg(QString::number(tmp_vox_triangles.at(i).matnum), QString::number(tmp_vox_triangles.at(i).color.x()), QString::number(tmp_vox_triangles.at(i).color.y()), QString::number(tmp_vox_triangles.at(i).color.z()));
//        if(tmp_vox_triangles.at(i).matnum == 13){
//            tmp_vox_triangles.remove(i);
//        }
//    }
//    updateEverything();
//    ui->obj3dViewer->func_vox_setTriangles(tmp_vox_triangles);

    //-start-色変更の例=ok
    //QVector<QOpenGLTriangle3D_vox> tmp_vox_triangles;
//    tmp_vox_triangles = g_vox_triangles;
//    for(int i=0; i < g_vox_triangles.count(); i++){
//        qDebug() << QString("\n\n[DEBUG]Vox3DForm.cpp-on_DEBUG01_pushButton_clicked() before matnum=%1 color=%2,%3,%4").arg(QString::number(tmp_vox_triangles.at(i).matnum), QString::number(tmp_vox_triangles.at(i).color.x()), QString::number(tmp_vox_triangles.at(i).color.y()), QString::number(tmp_vox_triangles.at(i).color.z()));
//        if(tmp_vox_triangles.at(i).matnum == 12){

//            QOpenGLTriangle3D_vox one_tri = tmp_vox_triangles.at(i);
//            one_tri.color = QVector3D(1, 0, 0); //赤
//            tmp_vox_triangles.replace(i, one_tri);
//        }
//    }
//    for(int i=0; i < g_vox_triangles.count(); i++){
//        qDebug() << QString("\n\n[DEBUG]Vox3DForm.cpp-on_DEBUG01_pushButton_clicked() after matnum=%1 color=%2,%3,%4").arg(QString::number(tmp_vox_triangles.at(i).matnum), QString::number(tmp_vox_triangles.at(i).color.x()), QString::number(tmp_vox_triangles.at(i).color.y()), QString::number(tmp_vox_triangles.at(i).color.z()));
//    }
//    updateEverything();
//    ui->obj3dViewer->func_vox_setTriangles(tmp_vox_triangles);
//    qDebug() << "\n\n[DEBUG]Vox3DForm.cpp-on_DEBUG01_pushButton_clicked() color-change End";
    //-end- 色変更の例
//}



//---------------------------------------------------------------------------------------------------------------------
//旧 2021.10.11-v2-NG void Vox3DForm::zNG_func_tableMaterialToGL() //for-vox  GL描画更新：ユーザーによるGUI操作された時点で、材質ごとの表示切替え・色切替え
//{
//    qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() start-time=" + QDateTime::currentDateTime().toString("hh:mm:ss");;

//    QStringList uiMatTableList = func_tableMaterial_gval(); //openGL描画処理の別cppに値渡しするため、グローバル変数更新
//    QList<int> nonViewMatList;
//    QVector<QVector3D> colorRGBvec;
//    QHash<int ,QVector3D> colorNameToRGBhash;
//    for(int i=0; i < uiMatTableList.count(); i++){
//        //qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() i=" << QString::number(i) << " tableMaterial_gval=" << uiMatTableList.at(i);
//        QStringList tmpStrList =  uiMatTableList.at(i).split(",");
//        int flag_chk = tmpStrList.at(0).toInt();
//        int matnum = tmpStrList.at(1).toInt();
//        QString colorname = tmpStrList.at(3);

//        if(flag_chk == 0 ){ nonViewMatList << matnum; }

//        QVector3D colorRGB = func_GL_defineColor_nameToRGBvec(colorname);
//        colorNameToRGBhash[matnum] = colorRGB;
//    }

//    QString tmpStr = "";
//    for(int i=0; i<nonViewMatList.size(); i++){ tmpStr += nonViewMatList.at(i); }
//    //qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() nonViewMatList=" << tmpStr;

//    foreach(int key, colorNameToRGBhash.keys()){
//        //qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() key" << QString::number(key) << " RGBcolor:x=" << QString::number(colorNameToRGBhash[key].x()) << " y=" << QString::number(colorNameToRGBhash[key].y()) << " z=" << QString::number(colorNameToRGBhash[key].z());
//    }

//    QVector<QOpenGLTriangle3D_vox> tmp_vox_triangles;
//    tmp_vox_triangles = g_vox_triangles;
//    for(int i = tmp_vox_triangles.count()-1; i>=0; i--){  // 非表示=削除処理の場合,インデックス番号に影響しないように、後ろから処理する
//        //qDebug() << QString("[DEBUG]01 Vox3DForm.cpp-func_tableMaterialToGL() i=%1 triangle_matnum=%2").arg(QString::number(i), QString::number(tmp_vox_triangles.at(i).matnum));

//        int matnum = tmp_vox_triangles.at(i).matnum;

//        // マテリアルテーブルの通りの色にする　...　全triangle変更なので遅くなるかも? チェックされたものだけ取得して対象にした方が良い？
//        if( colorNameToRGBhash.contains(matnum)){
//            //qDebug() << "[DEBUG]02 Vox3DForm.cpp-func_tableMaterialToGL()";
//            QVector3D colorRGB = colorNameToRGBhash[matnum];
//            QOpenGLTriangle3D_vox one_tri = tmp_vox_triangles.at(i);
//            //[DEBUG]// one_tri.color = QVector3D(1, 0, 0); //赤
//            one_tri.color = colorRGB;
//            tmp_vox_triangles.replace(i, one_tri);
//        }
//        //qDebug() << "[DEBUG]03 Vox3DForm.cpp-func_tableMaterialToGL()";

//        // マテリアルテーブルで表示チェックボックスOFFなら、非表示にする
//        //qDebug() << QString("\n\n[DEBUG]Vox3DForm.cpp-on_DEBUG01_pushButton_clicked() before matnum=%1 color=%2,%3,%4").arg(QString::number(tmp_vox_triangles.at(i).matnum), QString::number(tmp_vox_triangles.at(i).color.x()), QString::number(tmp_vox_triangles.at(i).color.y()), QString::number(tmp_vox_triangles.at(i).color.z()));
//        //if(tmp_vox_triangles.at(i).matnum == 13){
//        if(nonViewMatList.indexOf(tmp_vox_triangles.at(i).matnum) > -1 ){
//            //qDebug() << "[DEBUG]04 Vox3DForm.cpp-func_tableMaterialToGL()";
//            tmp_vox_triangles.remove(i);
//        }
//        //qDebug() << "[DEBUG]05 Vox3DForm.cpp-func_tableMaterialToGL()";
//    }
//    qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() -end- data-change time=" + QDateTime::currentDateTime().toString("hh:mm:ss");
//    qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() -start- openGL-update time=" + QDateTime::currentDateTime().toString("hh:mm:ss");
//    updateEverything();
//    ui->obj3dViewer->func_vox_setTriangles(tmp_vox_triangles);
//    qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() -end- openGL-update time=" + QDateTime::currentDateTime().toString("hh:mm:ss");
//}


/*
//---------------------------------------------------------------------------------------------------------------------
//旧 2021.10.13-v1  NG 動作はするけど　  実タイプで遅い　tmp_voxXYZVec.removeAt(pnum);　の箇所
void Vox3DForm::func_tableMaterialToGL() //for-vox  GL描画更新：ユーザーによるGUI操作された時点で、材質ごとの表示切替え・色切替え
{

    qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() start-time=" + QDateTime::currentDateTime().toString("hh:mm:ss");;

    QVector<QVector3D> tmp_voxXYZVec = g_voxXYZVec;
    QStringList tmp_voxSurfaceStrList = g_voxSurfaceStrList;
    QVector<QVector3D> tmp_voxColors = g_voxColorVec;
    QVector<int>tmp_voxMatnumVec = g_voxMatnumVec;

    //foreach(int key, g_voxMatToPnumHash.uniqueKeys()){  qDebug()  << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() g_voxMatToPnumHash key=" << QString::number(key) << " values=" << g_voxMatToPnumHash.values(key); }

    //GUI マテリアルテーブルから情報取得
    QStringList uiMatTableList = func_tableMaterial_gval(); //openGL描画処理の別cppに値渡しするため、グローバル変数更新
    QList<int> nonViewMatList;
    QVector<QVector3D> colorRGBvec;
    QHash<int, QVector3D> colorNameToRGBhash;
    QList<int> tableMatnumList;
    for(int i=0; i < uiMatTableList.count(); i++){
        QStringList tmpStrList =  uiMatTableList.at(i).trimmed().split(",");
        int flag_chk = tmpStrList.at(0).toInt();
        int matnum = tmpStrList.at(1).toInt();
        QString colorname = tmpStrList.at(3);

        if(flag_chk == 0 ){ nonViewMatList << matnum; }
        tableMatnumList << matnum;

        QVector3D colorRGB = func_GL_defineColor_nameToRGBvec(colorname);
        colorNameToRGBhash[matnum] = colorRGB;
    }

    QString tmpStr = "";

    //qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() nonViewMatList=" << nonViewMatList;
    //qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() tableMatnumList=" << tableMatnumList;
    //foreach(int key, colorNameToRGBhash.uniquekeys()){
    //    qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() key" << QString::number(key) << " RGBcolor:x=" << QString::number(colorNameToRGBhash[key].x()) << " y=" << QString::number(colorNameToRGBhash[key].y()) << " z=" << QString::number(colorNameToRGBhash[key].z());
    //}

    //削除 後ろから削除する チェックOFFのテーブルmatnumと合うものは ①全ての削除インデックス取得する　②後ろから消すためソートする　③g_　に関して削除
    QList<int> delpnumList;
    //①全ての削除インデックス取得する
    for(int i=0; i<nonViewMatList.size(); i++){
        int matnum = nonViewMatList.at(i);
        QList<int> tmpList =  g_voxMatToPnumHash.values(matnum);
        //qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() del-index matnum" << QString::number(matnum) <<  " tmpList=" << tmpList;
        if(g_voxMatToPnumHash.contains(matnum)){ delpnumList << tmpList; }
    }

    //②後ろから消すためソートする
    //std::sort(delpnumList.begin(), delpnumList.end(), std::greater<int>());  //降順　（大→小)で並べる
    std::sort(delpnumList.begin(), delpnumList.end()); //昇順(小→大で並べる） 削除処理時のfor は後ろから回す //delpnumList自身が直接書き換えられる
    std::unique(delpnumList.begin(), delpnumList.end()); //重複削除処理
    //delpnumList.removeAt(delpnumList.count()-1);    //末尾に残るゴミ(std::uniq処理特有)を削除
    //qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() [DEBUG]sorted-delpnumList="  <<  delpnumList;

    //for(int pnum=0; pnum < tmp_voxXYZVec.count() ; pnum++){
    //    qDebug() << "\n[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() before matnum " << QString::number(tmp_voxMatnumVec.at(pnum)) << " tmp_voxXYZvec" << tmp_voxXYZVec.at(pnum) << " surface=" << tmp_voxSurfaceStrList.at(pnum);
    //}

    //③関して削除     // できるが、ずれる。これから直す。
    for(int i=delpnumList.size()-1 ; i >=0 ; i--){
        int pnum = delpnumList.at(i);
        tmp_voxXYZVec.removeAt(pnum);
        tmp_voxSurfaceStrList.removeAt(pnum);
        tmp_voxColors.removeAt(pnum);
        tmp_voxMatnumVec.removeAt(pnum);
    }

    //qDebug() << "\n\n end-delete";
    //for(int pnum=0  ; pnum < tmp_voxXYZVec.count() ; pnum++){
    //    qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() after-deleted matnum " << QString::number(tmp_voxMatnumVec.at(pnum)) << " tmp_voxXYZvec" << tmp_voxXYZVec.at(pnum) << " surface=" << tmp_voxSurfaceStrList.at(pnum);
    //}

    //色設定 テーブルmatnumと合うものは　tmp_voxColorsのみReplaceする
    // できるが、ずれる。これから直す。
//    for(int i=0; i < tmp_voxMatnumVec.size(); i++){
//        int matnum = tmp_voxMatnumVec.at(i);
//        if(tableMatnumList.contains(matnum)){
//            tmp_voxColors.replace(i, colorNameToRGBhash[matnum]);
//        }
//    }

    //----------------------------------------------------
    //voxファイルからの取得情報を、openGL描画形式のデータに置き換える //openGLでの描画単位=1つの三角形ごとの情報作成する。
    QVector<QOpenGLTriangle3D_vox> tmp_triangles;
    qDebug() << "[DEBUG]voxRead_makeGLdata.cpp-func_01main_GL_make: start makeGLinfo " +  QDateTime::currentDateTime().toString("hh:mm:ss");
    func_GL_make_getPointOfMesh(tmp_triangles, tmp_voxXYZVec, tmp_voxSurfaceStrList, tmp_voxColors, tmp_voxMatnumVec);
    qDebug() << "[DEBUG]voxRead_makeGLdata.cpp-func_01main_GL_make: end makeGLinfo " +  QDateTime::currentDateTime().toString("hh:mm:ss");

    // 半透明ON/OFF設定 (全図形半透明 or 全図形通常表示)
    int flag_acolor = 0;
    if(ui->checkBox_acolor->isChecked()){ flag_acolor = 1; }
    ui->obj3dViewer->g_ui_acolorflag = flag_acolor;

    //voxファイルからの情報を渡して、openGL描画する
    qDebug() << "[DEBUG]Vox3DForm.cpp-on_DEBUG01_pushButton_clicked(): start openGL-draw-setTriangle " +  QDateTime::currentDateTime().toString("hh:mm:ss");
    //ui->obj3dViewer->func_vox_setTriangles(triangles);
    ui->obj3dViewer->func_vox_setTriangles(tmp_triangles);//グローバル変数に入れて、色切替え・表示切り替えできるようにする
    qDebug() << "[DEBUG]Vox3DForm.cpp-on_DEBUG01_pushButton_clicked(): end openGL-draw-setTriangle " +  QDateTime::currentDateTime().toString("hh:mm:ss");

}

 */
