#include "Vox3DForm.h"
#include "ui_Vox3DForm.h"

//-start- for-vox 2021.10.01

void Vox3DForm::on_pushButton_voxpathLoad_clicked()
{
    //ユーザーによるvoxファイル選択-------------------------------------------------------------------------
    QString loadfileName = "";
    QStringList tmpStringList;
    QString loadfileNameBefore;
    QString beforefilename , beforefilepath;
    QString tmpDirPath;

    //既にloadされているファイルがある場合はそのファイルがあるフォルダをファイル選択ダイアログの起点フォルダとする
    tmpDirPath =  "Desktop";
    if(ui->lineEdit_voxpath->text() != ""){
        tmpDirPath = QFileInfo(ui->lineEdit_voxpath->text()).absolutePath();
    }
    //loadfileName = QFileDialog::getOpenFileName(this, tr("Select file"), tmpDirPath, tr("text file (*.txt)"));
    loadfileName = QFileDialog::getOpenFileName(this, tr("Select file"), tmpDirPath);
    if(loadfileName.isEmpty() == 1 ){return;} // ファイル選択でキャンセルボタンが押されたら, そのまま終了。
    ui->lineEdit_voxpath->setText(loadfileName);


    //voxファイル読込み-------------------------------------------------------------------------
    qDebug() << "[DEBUG]Vox3DFormSub01.cpp-on_pushButton_voxpathLoad_clicked: start-all " +  QDateTime::currentDateTime().toString("hh:mm:ss");
    ui->label_voxmessage->setText("Now-loading");

    QString tmpstr;

    //QString voxfilepath = "c:/tmp/tmp.vox";
    //QString voxfilepath = QFileDialog::getOpenFileName(this,"Open vox",QStandardPaths::standardLocations(QStandardPaths::DesktopLocation).at(0) ) ; //, "*obj");
    QString voxfilepath = ui->lineEdit_voxpath->text();

    //マテリアルテーブルへのセット
    qDebug() << "[DEBUG]Vox3DFormSub01.cpp-on_pushButton_voxpathLoad_clicked: start set-materialTable " +  QDateTime::currentDateTime().toString("hh:mm:ss");
    QStringList lineList = func_getMaterialfromVoxPath(ui->lineEdit_voxpath->text());
    func_tableMaterialDefaultSet(lineList); //materialテーブルへの反映
    qDebug() << "[DEBUG]Vox3DFormSub01.cpp-on_pushButton_voxpathLoad_clicked: end set-materialTable " +  QDateTime::currentDateTime().toString("hh:mm:ss");

    //openGL描画処理
    qDebug() << "[DEBUG]Vox3DFormSub01.cpp-on_pushButton_voxpathLoad_clicked: start openGL-updateEverithing " +  QDateTime::currentDateTime().toString("hh:mm:ss");
    updateEverything(); //GUI　タブメニューmainTabの設定内容を、openGL描画処理に渡す
    qDebug() << "[DEBUG]Vox3DFormSub01.cpp-on_pushButton_voxpathLoad_clicked: end openGL-updateEverithing " +  QDateTime::currentDateTime().toString("hh:mm:ss");

    //QVector<QOpenGLTriangle3D_vox> triangles; //グローバル変数に置き換える
    QStringList comments;

    if(QFile(voxfilepath).exists())
    {
        //voxRead_makeGLdata().func_01main_GL_make_getPointOfMesh(triangles, voxfilepath);
        //voxRead_makeGLdata().func_01main_GL_make_getPointOfMesh(g_vox_triangles, voxfilepath); //グローバル変数に置き換える
        func_01main_GL_makeGL3DfromVox(g_vox_triangles, voxfilepath); //グローバル変数に入れて、色切替え・表示切り替えできるようにする

        // 半透明ON/OFF設定 (全図形半透明 or 全図形通常表示)
        int flag_acolor = 0;
        if(ui->checkBox_acolor->isChecked()){ flag_acolor = 1; }
        ui->obj3dViewer->g_ui_acolorflag = flag_acolor;

        //voxファイルからの情報を渡して、openGL描画する
        qDebug() << "[DEBUG]Vox3DForm.cpp-on_pushButton_voxpathLoad_clicked(): start openGL-draw-setTriangle " +  QDateTime::currentDateTime().toString("hh:mm:ss");
        //ui->obj3dViewer->func_vox_setTriangles(triangles);
        ui->obj3dViewer->func_vox_setTriangles(g_vox_triangles);//グローバル変数に入れて、色切替え・表示切り替えできるようにする
        qDebug() << "[DEBUG]Vox3DForm.cpp-on_pushButton_voxpathLoad_clicked(): end openGL-draw-setTriangle " +  QDateTime::currentDateTime().toString("hh:mm:ss");

        ui->label_voxmessage->setText(""); //読み込み終了。
    } else {
        QMessageBox::information(this, "notice", "file non-exsist " + voxfilepath);
    }

    qDebug() << "[DEBUG]Vox3DFormSub01.cpp-on_pushButton_voxpathLoad_clicked: end-all " +  QDateTime::currentDateTime().toString("hh:mm:ss");
}


void Vox3DForm::func_setGUIstartup(){ //for-vox GUIデフォルト表示など
    this->setWindowTitle("3Dviewer");

    if(g_DEBUGMODE == 0 ){
        //フォームを表示しない
        ui->label_rotateAngleY->setVisible(false);
        ui->lineEdit_rotateAngleY->setVisible(false);
        ui->label_rotateAngleZ->setVisible(false);
        ui->lineEdit_rotateAngleZ->setVisible(false);
        ui->pushButton_matTableToGL->setVisible(false);
        ui->DEBUG01_pushButton->setVisible(false);

        //ui->lookAtTab->setVisible(); //setVisibleでは消えない。
        ui->mainTabs->removeTab(ui->mainTabs->indexOf(ui->perspectiveTab));
        ui->mainTabs->removeTab(ui->mainTabs->indexOf(ui->lookAtTab)); //内部処理でGUIフォームの値変更しても落ちることなく動作している
        ui->mainTabs->removeTab(ui->mainTabs->indexOf(ui->transformTab));
        ui->mainTabs->removeTab(ui->mainTabs->indexOf(ui->textureTab));
        ui->mainTabs->removeTab(ui->mainTabs->indexOf(ui->diffuseLightTab));
    }

    ui->splitter_vox_01->setSizes(QList<int>() << 1000 << 300);

    ui->label_voxmessage->setText("");
    ui->vox_radioButton_mouseRotate->setChecked(true);

    ui->tableWidget_material->setColumnCount(5);
    QStringList labels;
    labels << "view" << "No" <<"MaterialName" << "color" << "color_toumei";
    ui->tableWidget_material->setHorizontalHeaderLabels(labels);
    ui->tableWidget_material->QTableWidget::horizontalHeader()->setStretchLastSection(true);
    //ui->tableWidget_material->setEditTriggers(QAbstractItemView::NoEditTriggers); //Table上の直接編集禁止
    ui->tableWidget_material->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget_material->setColumnWidth(0,50); //[0]列目(チェックボックス欄)の幅 50
    ui->tableWidget_material->setColumnWidth(2,200); //[2]列目(マテリアル名)の幅
    ui->tableWidget_material->setColumnWidth(3,130); //[3]列目(色名)の幅
    ui->tableWidget_material->setColumnWidth(4,50); //[4]列目(チェックボックス欄)の幅
    ui->tableWidget_material->hideColumn(1); //材質No 非表示にする ユーザーは見る必要もないため
    ui->tableWidget_material->hideColumn(4); //色透明　非表示にする　半透明切替が実装できたら表示する。それまでは非表示。
    ui->tableWidget_material->setMinimumWidth(430);
    g_flag_slotMatColorCombo = 1; //マテリアルコンボの値変更時にスロット処理させる:1 or させない:0。（ユーザー操作の時だけスロット処理したい。自動設定のとき（自動=初期設定の時など）はスロット処理したくない）
    g_flag_slotMatView = 1; //マテリアルコンボの値変更時にスロット処理させる:1 or させない:0。（ユーザー操作の時だけスロット処理したい。自動設定のとき（自動=初期設定の時など）はスロット処理したくない）

    //簡易回転　コンボボックス設定
    QStringList voxRotateComboList, voxRotateVComboList;
    voxRotateComboList << "front" << "left" << "back" << "right";
    voxRotateVComboList << "middle" << "top" << "bottom";
    ui->comboBox_voxRotate->addItems(voxRotateComboList);
    ui->comboBox_voxRotateV->addItems(voxRotateVComboList);

    QStringList voxLightPosComboList;
    voxLightPosComboList << "front" << "left" << "back" << "right";
    ui->comboBox_voxLightPos->addItems(voxLightPosComboList);

    //視点回転　ラベルにイメージ画像貼り付け
    //QPixmap tmppix("C:/kuroda/work/Qt/qt_work_3Dviewer/voxfile_viewer_MDIarea_H/images/cube_01.png");
    QPixmap tmppix(":/images/cube_01.png");
    //ui->label_voxRotateImg->setPixmap(tmppix.scaled(100,100));
    ui->label_voxRotateImg->setPixmap(tmppix.scaled(60,60));

    //マウス動作切替え (回転・平行移動)
    QStringList voxMouseActComboList;
    voxMouseActComboList << "Rotate" << "Shift" << "Nop" ;
    ui->vox_comboBox_mouseAct->addItems(voxMouseActComboList);
}

void Vox3DForm::on_checkBox_acolor_stateChanged(int arg1)
{
    //for vox
    // 半透明ON/OFF設定 (全図形 半透明にする)
    int flag_acolor = 0;
    if(ui->checkBox_acolor->isChecked()){ flag_acolor = 1; }
    ui->obj3dViewer->g_ui_acolorflag = flag_acolor;

    updateEverything(); //openGL widget更新
}

void Vox3DForm::func_tableMaterialDefaultSet(QStringList in_materialLineList) //materialテーブルのセット。マテリアルごとに表示・非表示, 色の変更などの用途。
{
    g_flag_slotMatColorCombo = 0 ; //マテリアル色コンボのスロット処理無効。自動設定の時にスロット処理されると実行エラーで落ちてしまうため。

    //[DEBUG]for(int i=0; i< in_materialLineList.size(); i++){  qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialDefaultSet materialLineList" + in_materialLineList.at(i); }

    //全行削除
    for(int row = ui->tableWidget_material->rowCount()-1; row >=0; row--){
        ui->tableWidget_material->removeRow(0);
    }

    //行追加
    //-start- [DEBUG]
    //QStringList srcList;
    //in_materialLineList << "11    mat11"; //タブ区切り　マテリアル番号とマテリアル名
    //in_materialLineList << "12    mat12";
    //in_materialLineList << "13    mat13";
    //-end- [DEBUG]
    QStringList srcList = in_materialLineList;
    for(int row =0; row < srcList.size(); row++){
        ui->tableWidget_material->insertRow(ui->tableWidget_material->rowCount());

        QStringList tmpList;
        tmpList = in_materialLineList.at(row).split("\t");

        //[0]列目　チェックボックス配置
        QCheckBox *pItemCheck0 = new QCheckBox();
        QWidget *pWidget0 = new QWidget();
        QHBoxLayout *pLayout0 = new QHBoxLayout();
        pItemCheck0->setCheckState(Qt::Checked);
        pLayout0->setAlignment(Qt::AlignCenter);
        pLayout0->addWidget(pItemCheck0);
        pWidget0->setLayout(pLayout0);
        ui->tableWidget_material->setCellWidget(ui->tableWidget_material->rowCount()-1, 0, pWidget0);
        //チェックボックスON/OFF切り替え時のアクション
        // int はチェック状態　引数はOFF=0 ON=2. 何行目がチェックされたか送りたいが、今の所方法が見つからない。→ SLOT処理でtable全体を見て処理するしかない。（今　変わったものだけに対してのアクションはできない。）
        connect(pItemCheck0, SIGNAL(stateChanged(int)), this, SLOT(func_tableMateriaRedrawSlot(int)));

        //[1]列目 マテリアル番号
        ui->tableWidget_material->setItem(row, 1, new QTableWidgetItem("")); //初期値
        if(tmpList.size() > 0){
            ui->tableWidget_material->setItem(row, 1, new QTableWidgetItem(tmpList.at(0)));
        }

        //[2]列目 マテリアル名
        ui->tableWidget_material->setItem(row, 2, new QTableWidgetItem("")); //初期値
        if(tmpList.size() > 0){
            ui->tableWidget_material->setItem(row, 2, new QTableWidgetItem(tmpList.at(1)));
        }

        //[3]列目　マテリアル色 コンボボックス配置
        //本番時はコメントアウト解除 これから関数作成//func_tableMaterialColorAdd(row);
        //コンボボックス初期色設定
        CustomCombo *tmp_combo= new(CustomCombo);
        tmp_combo->setFocusPolicy(Qt::StrongFocus);
        ui->tableWidget_material->setCellWidget(row, 3, tmp_combo);
        tmp_combo->addItems(QStringList() << "Black" <<"Gray" << "DarkGray" << "Lightgray" << "Green" <<"Brown" << "Purple"
                             << "MediumPurple" <<"Red" << "Magenta" << "Pink" << "Orange" << "Gold" << "Yellow"
                             << "Green" <<"Greenyellow" << "Olive" << "Navy" << "Blue" << "Cyan" << "Lightcyan"
                             );
        int tmpIndex = row % 10;
        tmp_combo->setCurrentIndex(tmpIndex);
        connect(tmp_combo, SIGNAL(currentIndexChanged(int)), this, SLOT(func_tableMaterialColorSlotChanged(int)));


        //[4]列目　マテリアル色-半透明 チェックボックス配置
        QCheckBox *pItemCheck1 = new QCheckBox();
        QWidget *pWidget1 = new QWidget();
        QHBoxLayout *pLayout1 = new QHBoxLayout();
        pItemCheck1->setCheckState(Qt::Checked);
        pLayout1->setAlignment(Qt::AlignCenter);
        pLayout1->addWidget(pItemCheck1);
        pWidget1->setLayout(pLayout1);
        ui->tableWidget_material->setCellWidget(ui->tableWidget_material->rowCount()-1, 4, pWidget1);
        //チェックボックスON/OFF切り替え時のアクション
        // int はチェック状態　引数はOFF=0 ON=2. 何行目がチェックされたか送りたいが、今の所方法が見つからない。→ SLOT処理でtable全体を見て処理するしかない。（今　変わったものだけに対してのアクションはできない。）
        //connect(pItemCheck0, SIGNAL(stateChanged(int)), this, SLOT(func_tableMaterialCheckAcolorSlotClicked(int)));

        if(tmpList.at(0)=="0"){
            //マテリアル番号:0 (Air) は表示させない。チェックボックスOFFにして、操作不可にする。
            pItemCheck0->setCheckState(Qt::Unchecked);
            pItemCheck0->setEnabled(false);
            //背景色グレーにする　2列目マテリアル番号, 3列目：マテリアル名
            ui->tableWidget_material->item(row, 1)->setBackground(Qt::lightGray);
            ui->tableWidget_material->item(row, 2)->setBackground(Qt::lightGray);
        }
    }

    func_tableMaterialDefaultSet_matnameToColorCombo(); //materialテーブルのセット。特定のマテリアルの場合、色設定コンボボックスを特定の色にセットする。

    g_flag_slotMatColorCombo = 1 ; //マテリアル色コンボのスロット処理有効に戻す。自動設定の時にスロット処理されると実行エラーで落ちてしまうため。
    //本番時までに直す 異常終了落ちてしまう// func_tableMaterialColorSlotChanged(); //マテリアル色コンボボックス部品の背景色を、表示されている値と同じにする(Red, Blue）など
}

void Vox3DForm::func_tableMateriaRedrawSlot(int) //ユーザー操作で、チェックボックス変更を, simNameテーブルに記録する
{
    qDebug() << "[DEBUG]Vox3DForm-func_tableMateriaRedrawSlot start";

    if(g_flag_slotMatView == 0){ return; } //処理無効が指定されていたら、処理なし。
    if(g_flag_slotMatColorCombo == 0){ return; } //処理無効が指定されていたら、処理なし。

    QStringList uiTableListMat = func_tableMaterial_gval();
    QString filepath = ui->lineEdit_voxpath->text();
    func_tableMaterialToGL(); //for-vox  GL描画更新：ユーザーによるGUI操作された時点で、材質ごとの表示切替え・色切替え
}

void Vox3DForm::func_tableMaterialColorSlotChanged(int index) //ユーザー操作で、マテリアル色選択コンボボックスが変わった場合の処理
{
    if(g_flag_slotMatColorCombo == 0){ return; } //処理無効が指定されていたら、処理なし。

    func_tableMateriaRedrawSlot(1); //GL画面をテーブル通りの表示・表示、色で更新

    return; //[DEBUG]本番時は削除する

    QStringList materiallist, materialcolorlist;
    for(int row=0; row < ui->tableWidget_material->rowCount(); row++){
        materiallist += ui->tableWidget_material->item(row,2)->text();

        CustomCombo *tmpcombo = new CustomCombo;
        tmpcombo = static_cast<CustomCombo*>(ui->tableWidget_material->cellWidget(row, 3));
        QString tmpcolorText = tmpcombo->currentText();
        materialcolorlist += tmpcolorText;

        //コンボボックスウィジェットに色付け
        if(tmpcolorText == "Black"){
            //combocolor->setItemData(0, QColor(0,0,0,255), Qt::BackgroundRole); //01 Black
            //combocolor->setItemData(0, QColor(Qt::white), Qt::TextColorRole);
            tmpcombo->setStyleSheet("QComboBox { background-color: #000000; color:#ffffff;}"); //背景:黒　文字色：白
        }
        if(tmpcolorText == "Lightgray"){
            tmpcombo->setStyleSheet("QComboBox { background-color: #d3d3d3 }"); //背景:灰色　文字色：デフォルト
        }
        //↑正しくは全色設定するべき　現在途中まで。

        QStringList uiTableListMat = func_tableMaterial_gval(); //openGL描画処理の別cppに値渡しするため、グローバル変数更新
        QString filepath = ui->lineEdit_voxpath->text();
        //◆これから記述する予定 別cppへの値渡しと openGL描画処理呼び出し

    }

    //openGL

}


//QStringList Vox3DForm::func_gval_table_material() //GL描画処理用の別cpp への値渡しのため、グローバル変数を更新する。
QStringList Vox3DForm::func_tableMaterial_gval() //GL描画処理用の別cpp への値渡しのため、グローバル変数を更新する。
{
    QStringList lineList;
    for(int row=0; row < ui->tableWidget_material->rowCount(); row++){
       QString oneline = "";
       for(int col=0; col < ui->tableWidget_material->horizontalHeader()->count(); col++){
           QString colstr = "";
           if(col != 0 && col != 3 && col != 4){colstr = ui->tableWidget_material->item(row, col)->text(); }
           if(col==0 || col==4){
                //テーブル チェックボックス状態
                QWidget *pWidget = ui->tableWidget_material->cellWidget(row,0);
                QCheckBox *checkbox = pWidget->findChild<QCheckBox *>();
                QString check = "0";
                if(checkbox->isChecked()){ check = "1"; }
                colstr = check; //1列目
           }
           if(col==3){
                //テーブル comboBox状態
               QComboBox *tmpcombo = new QComboBox();
               tmpcombo = static_cast<QComboBox*>(ui->tableWidget_material->cellWidget(row, 3));
               colstr = tmpcombo->currentText();
           }
           oneline += colstr + ",";
        }
        oneline.chop(1); //最後の "," は削除する
        lineList << oneline;
    }

    //QMessageBox::information(this, "notice", msg);
    //qDebug() << "[DEBUG]func_tableComboMy01_changed() " + linelist


    return(lineList);
}

QStringList Vox3DForm::func_getMaterialfromVoxPath(QString in_filepath) //voxfile からマテリアル行のみ取得する。
{
    QStringList filelineList;
    QFile file(in_filepath);
    if(!file.open(QIODevice::ReadOnly)){
        QString errStr =  "file open error:" + file.errorString();
        qDebug() << errStr;
        //return(lines);
    }
    QTextStream in(&file);
    while(!in.atEnd()){
        QString fileLine = in.readLine(0);
        if(fileLine.startsWith("CellData")){ break; }
        if(fileLine.startsWith("Version") || fileLine.endsWith("precision") || fileLine.endsWith("unitlength")){
            continue;
        }
        filelineList << fileLine;
    }
    return(filelineList);
}

void Vox3DForm::func_tableMaterialColorAdd(int in_row) //table_material の指定行in_row に色付きComboBOX1個を登録する
{
    CustomCombo *combocolor = new CustomCombo(this);
    combocolor->setFocusPolicy(Qt::StrongFocus);

    combocolor->addItems(QStringList() << "Black" <<"Gray" << "Lightgray" << "Green" <<"Brown" << "Purple"
                         << "MidiumPurple" <<"Red" << "Magenta" << "Pink" << "Orange" << "Gold " << "Yellow"
                         << "Green" <<"Greenyellow" << "Olive" << "Navy" << "Blue" << "Cyan" << "Lightcyan"
                         );

    //1つのComboBoxの選択肢の見た目設定　背景色・文字色
    combocolor->setItemData(0, QColor(0, 0, 0,255), Qt::BackgroundRole); //00 Black 背景色
    combocolor->setItemData(0, QColor(Qt::white), Qt::TextColorRole); //00 Black 文字色
    combocolor->setItemData(1, QColor(128, 128, 128,255), Qt::BackgroundRole); //01 Gray
    combocolor->setItemData(1, QColor(Qt::white), Qt::TextColorRole);
    combocolor->setItemData(2, QColor(211, 211, 211,255), Qt::BackgroundRole); //02 Lightgray
    //combocolor->setItemData(3, QColor(255, 255, 255,255), Qt::BackgroundRole); //03 White
    combocolor->setItemData(3, QColor(0, 255, 0,255), Qt::BackgroundRole); //03 Green //暫定置き換え White->Green  //openGL背景白と重ならないようにするため
    combocolor->setItemData(3, QColor(Qt::white), Qt::TextColorRole);

    combocolor->setItemData(4, QColor(165, 42, 42,255), Qt::BackgroundRole); //04 Brown
    combocolor->setItemData(4, QColor(Qt::white), Qt::TextColorRole);
    combocolor->setItemData(5, QColor(128, 0, 128,255), Qt::BackgroundRole); //05 Purple
    combocolor->setItemData(5, QColor(Qt::white), Qt::TextColorRole);
    combocolor->setItemData(6, QColor(147, 112, 219,255), Qt::BackgroundRole); //06 MediumPurple
    combocolor->setItemData(6, QColor(Qt::white), Qt::TextColorRole);
    combocolor->setItemData(7, QColor(255, 0, 0, 255), Qt::BackgroundRole); //07 Red
    combocolor->setItemData(8, QColor(255, 0, 255, 255), Qt::BackgroundRole); //08 Magenta
    combocolor->setItemData(9, QColor(255, 192, 203,255), Qt::BackgroundRole); //09 Pink
    combocolor->setItemData(10, QColor(255, 165, 0, 255), Qt::BackgroundRole); //10 Orange
    combocolor->setItemData(11, QColor(255, 215, 0, 255), Qt::BackgroundRole); //11 Gold
    combocolor->setItemData(12, QColor(255, 255, 0, 255), Qt::BackgroundRole); //12 Yellow
    combocolor->setItemData(13, QColor(0, 255, 0,255), Qt::BackgroundRole); //13 Green
    combocolor->setItemData(13, QColor(Qt::white), Qt::TextColorRole);
    combocolor->setItemData(14, QColor(173, 255, 47, 255), Qt::BackgroundRole); //14 Greenyellow
    combocolor->setItemData(14, QColor(128, 128, 0, 255), Qt::BackgroundRole); //15 Olive
    //↑サンプルとして途中まで。。

    //本番時はコメントアウト解除する// connect(combocolor, SIGNAL(currentIndexChanged(QString)), this, SLOT(func_tableMaterialColorSlotChanged()))); //materialテーブルのセット。マテリアルごとに表示・非表示, 色の変更などの用途。
    ui->tableWidget_material->setCellWidget(in_row, 3, combocolor);
}


void Vox3DForm::on_DEBUG01_pushButton_clicked() //for-vox
{   
    ui->obj3dViewer->func_vox_setRotation(ui->lineEdit_rotateAngleY->text().toFloat(),
                                 ui->lineEdit_rotateAngleZ->text().toFloat()
                                 );

    ui->obj3dViewer->update(); // have to call this manually (for better performance)
}

void Vox3DForm::on_pushButton_matTableToGL_clicked()
{
     func_tableMaterialToGL(); //for-vox  GL描画更新：ユーザーによるGUI操作された時点で、材質ごとの表示切替え・色切替え
}

void Vox3DForm::func_tableMaterialToGL() //for-vox  GL描画更新：ユーザーによるGUI操作された時点で、材質ごとの表示切替え・色切替え
{

    qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() start-time=" + QDateTime::currentDateTime().toString("hh:mm:ss");;

    //foreach(int key, g_voxMatToPnumHash.uniqueKeys()){  qDebug()  << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() g_voxMatToPnumHash key=" << QString::number(key) << " values=" << g_voxMatToPnumHash.values(key); }

    //GUI マテリアルテーブルから情報取得
    QStringList uiMatTableList = func_tableMaterial_gval(); //openGL描画処理の別cppに値渡しするため、グローバル変数更新
    QList<int> nonDrawMatList, drawMatList;
    QVector<QVector3D> colorRGBvec;
    QHash<int, QVector3D> colorNameToRGBhash;
    QList<int> tableMatnumList;
    for(int i=0; i < uiMatTableList.count(); i++){
        QStringList tmpStrList =  uiMatTableList.at(i).trimmed().split(",");
        int flag_chk = tmpStrList.at(0).toInt();
        int matnum = tmpStrList.at(1).toInt();
        QString colorname = tmpStrList.at(3);

        if(flag_chk == 0 ){ nonDrawMatList << matnum; }
        if(flag_chk == 1 ){ drawMatList << matnum; }
        tableMatnumList << matnum;

        QVector3D colorRGB = func_GL_defineColor_nameToRGBvec(colorname);
        colorNameToRGBhash[matnum] = colorRGB;
    }

    QString tmpStr = "";

    //qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() nonDrawMatList=" << nonDrawMatList;
    //qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() tableMatnumList=" << tableMatnumList;
    //foreach(int key, colorNameToRGBhash.uniquekeys()){
    //    qDebug() << "[DEBUG]Vox3DForm.cpp-func_tableMaterialToGL() key" << QString::number(key) << " RGBcolor:x=" << QString::number(colorNameToRGBhash[key].x()) << " y=" << QString::number(colorNameToRGBhash[key].y()) << " z=" << QString::number(colorNameToRGBhash[key].z());
    //}


    //表示切替　GUIテーブル:チェックONだけ表示する、OFF表示なし / 色・コンボボックス指定の色にする
    QVector<QVector3D> tmp_voxXYZVec;
    QStringList tmp_voxSurfaceStrList;
    QVector<QVector3D> tmp_voxColorVec;
    QVector<int>tmp_voxMatnumVec;
    for(int pnum=0; pnum < g_voxMatnumVec.size() ; pnum++){
        int matnum = g_voxMatnumVec.at(pnum);
        if(drawMatList.indexOf(matnum) > -1){
            tmp_voxXYZVec.append(g_voxXYZVec.at(pnum));
            tmp_voxSurfaceStrList.append(g_voxSurfaceStrList.at(pnum));
            tmp_voxMatnumVec.append(g_voxMatnumVec.at(pnum));
            tmp_voxColorVec.append(colorNameToRGBhash[matnum]); //色・コンボボックス指定の色にする
        }
    }


    //----------------------------------------------------
    //voxファイルからの取得情報を、openGL描画形式のデータに置き換える //openGLでの描画単位=1つの三角形ごとの情報作成する。
    QVector<QOpenGLTriangle3D_vox> tmp_triangles;
    qDebug() << "[DEBUG]voxRead_makeGLdata.cpp-func_01main_GL_make: start makeGLinfo " +  QDateTime::currentDateTime().toString("hh:mm:ss");
    func_GL_make_getPointOfMesh(tmp_triangles, tmp_voxXYZVec, tmp_voxSurfaceStrList, tmp_voxColorVec, tmp_voxMatnumVec);
    qDebug() << "[DEBUG]voxRead_makeGLdata.cpp-func_01main_GL_make: end makeGLinfo " +  QDateTime::currentDateTime().toString("hh:mm:ss");

    // 半透明ON/OFF設定 (全図形半透明 or 全図形通常表示)
    int flag_acolor = 0;
    if(ui->checkBox_acolor->isChecked()){ flag_acolor = 1; }
    ui->obj3dViewer->g_ui_acolorflag = flag_acolor;

    //voxファイルからの情報を渡して、openGL描画する
    qDebug() << "[DEBUG]Vox3DForm.cpp-on_DEBUG01_pushButton_clicked(): start openGL-draw-setTriangle " +  QDateTime::currentDateTime().toString("hh:mm:ss");
    //ui->obj3dViewer->func_vox_setTriangles(triangles);
    ui->obj3dViewer->func_vox_setTriangles(tmp_triangles);//グローバル変数に入れて、色切替え・表示切り替えできるようにする
    qDebug() << "[DEBUG]Vox3DForm.cpp-on_DEBUG01_pushButton_clicked(): end openGL-draw-setTriangle " +  QDateTime::currentDateTime().toString("hh:mm:ss");

}




void Vox3DForm::on_pushButton_viewAllOn_clicked()
{
    g_flag_slotMatView = 0; //スロット処理無効にする　（都度変更されて、GL反映だと時間がかかりすぎるため）

    for(int row=0; row < ui->tableWidget_material->rowCount(); row++){
        QWidget *pWidget = ui->tableWidget_material->cellWidget(row, 0);
        QCheckBox *checkbox = pWidget->findChild<QCheckBox *>();
        checkbox->setChecked(true);
    }

    g_flag_slotMatView = 1; //スロット処理有効に戻す

    func_tableMateriaRedrawSlot(1); //GL画面をテーブル通りの表示・表示、色で更新
}


void Vox3DForm::on_pushButton_viewAllOff_clicked()
{
    for(int row=0; row < ui->tableWidget_material->rowCount(); row++){
        QWidget *pWidget = ui->tableWidget_material->cellWidget(row, 0);
        QCheckBox *checkbox = pWidget->findChild<QCheckBox *>();
        checkbox->setChecked(false);
    }

    g_flag_slotMatView = 1; //スロット処理有効に戻す

    func_tableMateriaRedrawSlot(1); //GL画面をテーブル通りの表示・表示、色で更新
}

void Vox3DForm::on_lineEdit_rotateAngleY_editingFinished()
{
    ui->obj3dViewer->func_vox_setRotation(ui->lineEdit_rotateAngleY->text().toFloat(),
                                 ui->lineEdit_rotateAngleZ->text().toFloat()
                                 );

    ui->obj3dViewer->update(); // have to call this manually (for better performance)
}

void Vox3DForm::on_lineEdit_rotateAngleZ_editingFinished()
{
    ui->obj3dViewer->func_vox_setRotation(ui->lineEdit_rotateAngleY->text().toFloat(),
                                 ui->lineEdit_rotateAngleZ->text().toFloat()
                                 );

    ui->obj3dViewer->update(); // have to call this manually (for better performance)
}

void Vox3DForm::on_vox_pushButton_setDefaultViewMenu_clicked()
{
    //タブ VoxOption
    ui->comboBox_voxRotate->setCurrentText("front");

    //タブ perspective
    ui->persVerticalAngleSpin->setValue(30.00);
    //ui->persNearSpin->setValue(0.10);
    ui->persFarSpin->setValue(100.00);

    //タブ Look At
    ui->lookEyeXSpin->setValue(-5.00);
    ui->lookEyeYSpin->setValue(2.00);
    ui->lookEyeZSpin->setValue(5.00);

    ui->lookCenterXSpin->setValue(0.00);
    ui->lookCenterYSpin->setValue(0.00);
    ui->lookCenterZSpin->setValue(0.00);

    ui->lookUpXSpin->setValue(0.00);
    ui->lookUpYSpin->setValue(1.00);
    ui->lookUpZSpin->setValue(0.00);

    //タブ Transration
    ui->scaleSpin->setValue(1.00);

    ui->translateXSpin->setValue(0.00);
    ui->translateYSpin->setValue(0.00);
    ui->translateZSpin->setValue(0.00);

    ui->rotateAngleSlider->setValue(0.00);
    ui->rotateXSpin->setValue(0.00);
    ui->rotateYSpin->setValue(0.00);
    ui->rotateZSpin->setValue(0.00);

    //タブ Texture
    //ui->textureFileEdit->setText("");

    //タブ Diffuse
    ui->lightPosXSpin->setValue(-25.00);
    ui->lightPosYSpin ->setValue(25.00);
    ui->lightPosZSpin ->setValue(25.00);

    ui->lightKd1Spin->setValue(0.00);
    ui->lightKd2Spin->setValue(1.00);
    ui->lightKd3Spin->setValue(0.00);

    ui->lightLd1Spin->setValue(1.00);
    ui->lightLd2Spin->setValue(1.00);
    ui->lightLd3Spin->setValue(1.00);

    ui->obj3dViewer->update();
}

void Vox3DForm::func_slot_mousewheelZoom(float in_modelScale){
    ui->scaleSpin->setValue(double(in_modelScale)); // 値セットするだけで、GUI変更によるシグナルスロット　on_scaleSpin_valueChanged　でopenGL画面が更新される
}

//void Vox3DForm::on_checkBox_voxshift_stateChanged(int arg1)
//{
//    ui->obj3dViewer->g_ui_voxshiftflag = 0;
//    if(ui->checkBox_voxshift->isChecked()){
//        ui->obj3dViewer->g_ui_voxshiftflag = 1;
//    }
//}

void Vox3DForm::func_slot_mouseRotate(float in_rotateAngleY, float in_rotateAngleZ){
    //通常は、マウスドラッグで図形回転モード (GUIで図形平行移動モード=チェックOFFの場合)
    //qDebug() << "[DEBUG]01 Vox3DFormSub01.cpp-func_slot_mouseRotate.cpp";
//    ui->lineEdit_rotateAngleY->setText(QString::number(in_rotateAngleY));
//    ui->lineEdit_rotateAngleZ->setText(QString::number(in_rotateAngleZ));
//    ui->obj3dViewer->update();
}

void Vox3DForm::func_slot_mouseDrag02(int in_mouseMoveX, int in_mouseMoveY){ //マウスドラッグ時の動作。
    //qDebug() << QString("[DEBUG]Vox3DForm.cpp-func_slot_mouseDrag02 %d %d").arg( in_mouseMoveX, in_mouseMoveY );
//    if(ui->vox_radioButton_mouseRotate->isChecked()){
//        func_slot_mouseVoxRotate(in_mouseMoveX, in_mouseMoveY);
//    }
//    if(ui->vox_radioButton_mouseShift->isChecked()){
//        func_slot_mouseVoxShift(in_mouseMoveX, in_mouseMoveY);
//    }

    if(ui->vox_comboBox_mouseAct->currentText() == "Rotate"){
        func_slot_mouseVoxRotate(in_mouseMoveX, in_mouseMoveY);
    }
    if(ui->vox_comboBox_mouseAct->currentText() == "Shift"){
        qDebug() << "[DEBUG]01 Vox3DForm.cpp-func_slot_mouseDrag02";
        func_slot_mouseVoxShift(in_mouseMoveX, in_mouseMoveY);
    }
}

void Vox3DForm::func_slot_mouseVoxRotate(int in_mouseMoveX, int in_mouseMoveY){
    double alpha, beta;
    int deltaX = in_mouseMoveX;
    int deltaY = in_mouseMoveY;
    alpha = 0; //後で修正する　eyeX・Y・Zの位置から計算する　XY面の角度を計算する
    beta  = 0; //後で修正する　eyeX・Y・Zの位置から計算する　YZ（XZかも?)面の角度を計算する
    alpha -= double(deltaX);
    while (alpha < 0) {
        alpha += 360;
    }
    while (alpha >= 360) {
        alpha -= 360;
    }

    beta -= double(deltaY);
    if (beta < -90) {
        beta = -90;
    }
    if (beta > 90) {
        beta = 90;
    }

    double alphaV = 0;
    alphaV -= double(deltaY);
    while (alphaV < 0) {
        alphaV += 360;
    }
    while (alphaV >= 360) {
        alphaV -= 360;
    }
    double alphaRad = alpha * M_PI / 180;
    double alphaVRad = alphaV * M_PI / 180;

    //qDebug() << "[DEBUG]Vox3DForm::func_slot_mouseDrag02 mouseMove alpha=" << QString::number(alpha) << " beta=" << QString::number(beta) ;
    //qDebug() << "\n[DEBUG]Vox3DForm::func_slot_mouseDrag02 mouseMove mouseMoveX=" << QString::number(in_mouseMoveX) << " mouseMoveY=" << QString::number(in_mouseMoveY) ;
    //qDebug() << "[DEBUG]Vox3DForm::func_slot_mouseDrag02 alpha　deg=" << QString::number(alpha) << " rad=" << QString::number(alphaRad) << " alphaV deg=" << QString::number(alphaV)  << " rad=" << QString::number(alphaVRad) ;

    //通常は、マウスドラッグで図形回転モード(カメラ視点を変える。追従して光源方向も変える。）
    double circleLen = 5; //カメラ位置 直径決め打ち

    //水平方向回転 右にドラッグ→時計回りに回転　左にドラッグ→反時計回りに回転。
    //問題あり、これから直す。270°以上になった時に、271°でなく0°（？）にスキップしてしまう。。
    double tmpX, tmpY, angleRad, before_angleRad;
    tmpX = ui->lookEyeXSpin->value();
    tmpY = ui->lookEyeZSpin->value(); //フォームのEyeZSpin 水平方向(Y)　(GL座標のネーミングになっている?）
    //qDebug() << "[DEBUG]Vox3DForm::func_slot_mouseDrag02 suihei before-GUI tmpX=" << QString::number(tmpX) << " tmpY=" << QString::number(tmpY) ;
    angleRad = atan(tmpY/tmpX); // 単位：ラジアン
    before_angleRad = angleRad;
    angleRad += alphaRad;
    tmpX = cos(angleRad) * circleLen ; //[DEBUG]直径5決め打ち
    tmpY = sin(angleRad) * circleLen ; //[DEBUG]直径5決め打ち
    //qDebug() << "[DEBUG]Vox3DForm::func_slot_mouseDrag02 angleRad before-rad " << QString::number(before_angleRad) <<  " rad=" << QString::number(angleRad) << " degree=" << QString::number(angleRad * 180/M_PI) << " tmpX=" << QString::number(tmpX) << " tmpY=" << QString::number(tmpY);
    ui->lookEyeXSpin->setValue(tmpX);
    ui->lookEyeZSpin->setValue(tmpY);

    //垂直方向回転　上にドラッグ→時計回りに回転　下にドラッグ→反時計回りに回転。
    double tmpZ =ui->lookEyeYSpin->value(); //フォームのEyeYSpin 上下方向　(GL座標のネーミングになっている?）
    //qDebug() << "[DEBUG]Vox3DForm::func_slot_mouseDrag02 before-GUI tmpZ=" << QString::number(tmpZ) << "  alphaVRad=" << QString::number(alphaVRad) ;
    double zplus = abs( circleLen * sin(alphaVRad) );
    if(in_mouseMoveY > 0  && tmpZ + zplus < circleLen){
        tmpZ = tmpZ + zplus ;
    }
    if(in_mouseMoveY < 0  && tmpZ - zplus > -circleLen){
        tmpZ = tmpZ - zplus ;
    }
    ui->lookEyeYSpin->setValue(tmpZ);

    //光源もカメラの位置に追従
    double lightPosX = abs(ui->lightPosXSpin->value());
    double lightPosY = abs(ui->lightPosYSpin->value());
    double lightPosZ = abs(ui->lightPosZSpin->value());
    if(ui->lookEyeXSpin->value() < 0) { lightPosX = -1 * lightPosX ; } //openGL座標のネーミング　lightPosZ=Y方向
    if(ui->lookEyeYSpin->value() < 0) { lightPosY = -1 * lightPosY ; } //openGL座標のネーミング　Z方向
    if(ui->lookEyeZSpin->value() < 0) { lightPosZ = -1 * lightPosZ ; } //openGL座標のネーミング　lookEyeZSpin=Y方向
    ui->lightPosXSpin->setValue(lightPosX);
    ui->lightPosYSpin->setValue(lightPosY);
    ui->lightPosZSpin->setValue(lightPosZ);

}

void Vox3DForm::func_slot_mouseVoxShift(int in_mouseMoveX, int in_mouseMoveY){
    //マウスドラッグで図形平行移動モードONの場合  マウスドラッグで平行移動。　0:平行移動モードはOFF（OFFのときは、マウスドラッグで図形回転モード)
    //試し中　視点位置E eye と　注視点を変更 （もとの角度のまま両方　平行移動させる）

    //　glXZ平面 = 通常 XY平面  glZ手前マイナス、奥がプラス
    //                          | glZ(-)
    //                          |
    //      2象限(定位置Left)     |    1象限(定位置back)
    //                          |
    // glX(-)                   |                       glX(+)
    // ----------------------------------------------------------
    //                          |
    //                          |
    //      3象限(定位置Front)    |    4象限(定位置Right)
    //                          |
    //                          | glZ(+)

    //double mouseMoveH = double(in_mouseMoveX);
    double mouseMoveH = (double(in_mouseMoveX) / ui->obj3dViewer->width()) * 3 ; //width()=表示範囲全体 //*3は移動幅調整。値は適当。
    double anglerad = atan(abs(ui->lookEyeXSpin->value()) / abs(ui->lookEyeZSpin->value()));
    double transGLX = mouseMoveH * cos(abs(anglerad));
    double transGLZ = mouseMoveH * cos(abs(M_PI/2 - abs(anglerad)));

    //注視線に直角の線上を進む。進む方向に対応するように、マイナスを掛ける。
    //マウス移動H方向(左右) 視点位置が glXZ平面　第3象限の場合 (定位置Front) 動作Ok-45°以外も
    //if(ui->lookEyeXSpin->value() < 0 && ui->lookEyeZSpin->value() > 0){
        //注視線に直角の線の進行方向は、第4象限 glX方向+ , glY方向＋　なので処理なし
    //}


    //H方向 左右 視点位置がXY平面　第1象限の場合 (定位置Back） 動作Ok-45°以外も
    if(ui->lookEyeXSpin->value() > 0 && ui->lookEyeZSpin->value() < 0){
        //注視線に直角の線の進行方向は、第2象限 glX方向- , glY方向-
        transGLX = -1 * transGLX ;
        transGLZ = -1 * transGLZ ;
    }

    //H方向 左右 視点位置がXY平面　第2象限の場合 動作Ok-45°以外も (定位置Left)
    if(ui->lookEyeXSpin->value() < 0 && ui->lookEyeZSpin->value() < 0){
        transGLX = -1 * transGLX ;
    }

    //H方向 左右 視点位置がXY平面　第4象限の場合 動作test (定位置Right)
    if(ui->lookEyeXSpin->value() > 0 && ui->lookEyeZSpin->value() > 0){
        //注視線に直角の線の進行方向は、第1象限 glX方向+ , glY方向-
        transGLZ = -1 * transGLZ ;
    }

    //qDebug() << "[DEBUG]Vox3DForm.cpp-func_slot_mouseVoxShsift moveMouse mouseMoveH=" << QString::number(mouseMoveH);
    //qDebug() << "[DEBUG]Vox3DForm.cpp-func_slot_mouseVoxShift moveMouse anglerad=" << QString::number(anglerad) << " angle-degree=" << QString::number(anglerad * 180/M_PI);
    //qDebug() << "[DEBUG]Vox3DForm.cpp-func_slot_mouseVoxShift transGLX=" << QString::number(transGLX) << " transGLZ=" << QString::number(transGLZ);
    ui->translateXSpin->setValue(ui->translateXSpin->value() + transGLX);
    ui->translateZSpin->setValue(ui->translateZSpin->value() + transGLZ);

    //V方向 上下　translate
    double mouseMoveV = (double(in_mouseMoveY) / ui->obj3dViewer->height()) * -1 ; //heght()=表示範囲全体 //mouseMoveYは下移動するときマイナス値、上移動するときプラス値？
    //double mouseMoveV = (double(in_mouseMoveY)) * -1;
    ui->translateYSpin->setValue(ui->translateYSpin->value() + mouseMoveV);

}


void Vox3DForm::on_comboBox_voxRotate_currentIndexChanged(const QString &arg1)
{
    //カメラ位置　通常座標X,Y 方向設定　(GUI GL座標 eyeX=通常座標X方向. eyeZ=通常座標(-)Y方向:手前+,奥-)
    QString selectname = ui->comboBox_voxRotate->currentText();
    QString tmpImg = "cube_01.png";
    double eyeX = -5;
    double eyeZ = 5;  //GL座標 eyeZ = 通常座標(-)Y方向:手前+,奥-
    double lightPosX = -25;
    double lightPosZ = 25;
    QPixmap tmpPix;
    if(selectname == "front"){
        eyeX = -5;
        eyeZ = 5;
        lightPosX = -25;
        lightPosZ = 25;
        tmpImg = "cube_01.png";
    }
    if(selectname == "left"){
        eyeX = -5;
        eyeZ = -5;
        lightPosX = -25;
        lightPosZ = -25;
        tmpImg = "cube_02.png";
    }
    if(selectname == "back"){
        eyeX = 5;
        eyeZ = -5;
        lightPosX = 25;
        lightPosZ = -25;
        tmpImg = "cube_03.png";
    }
    if(selectname == "right"){
        eyeX = 5;
        eyeZ = 5;
        lightPosX = 25;
        lightPosZ = 25;
        tmpImg = "cube_04.png";
    }
    //[DEBUG]//QPixmap tmpPix(":/images/cube_01.png");
    tmpPix = QPixmap(":/images/" + tmpImg);
    //ui->label_voxRotateImg->setPixmap(tmpPix.scaled(100,100));
    ui->label_voxRotateImg->setPixmap(tmpPix.scaled(60,60));

    //カメラ位置　通常座標Z 方向設定 GL座標 eyeY = 通常座標Z方向
    selectname = ui->comboBox_voxRotateV->currentText();
    double eyeY = 2; //GL座標 eyeY = 通常座標Z方向
    double lightPosY = 25;
    if(selectname == "middle"){ eyeY = 2;}
    if(selectname == "top"){ eyeY = 5; }
    if(selectname == "bottom"){
        eyeY = -5;
        lightPosY = -25;
    }

    ui->lookEyeXSpin->setValue(eyeX);
    ui->lookEyeYSpin->setValue(eyeY);
    ui->lookEyeZSpin->setValue(eyeZ);

    ui->lightPosXSpin->setValue(lightPosX);
    ui->lightPosYSpin->setValue(lightPosY);
    ui->lightPosZSpin->setValue(lightPosZ);
}


void Vox3DForm::on_comboBox_voxRotateV_currentIndexChanged(const QString &arg1)
{
    on_comboBox_voxRotate_currentIndexChanged(0); //引数は影響しないはず
}

void Vox3DForm::on_comboBox_voxLightPos_currentTextChanged(const QString &arg1)
{
    //カメラ位置　通常座標X,Y 方向設定　(GUI GL座標 eyeX=通常座標X方向. eyeZ=通常座標(-)Y方向:手前+,奥-)
    QString selectname = ui->comboBox_voxLightPos->currentText();
    QString tmpImg = "cube_01.png";
    double lightPosX = -25;
    double lightPosZ = 25;
    if(selectname == "front"){
        lightPosX = -25;
        lightPosZ = 25;
    }
    if(selectname == "left"){
        lightPosX = -25;
        lightPosZ = -25;
    }
    if(selectname == "back"){
        lightPosX = 25;
        lightPosZ = -25;
    }
    if(selectname == "right"){
        lightPosX = 25;
        lightPosZ = 25;
    }
    //カメラ位置　通常座標Z 方向設定 GL座標 eyeY = 通常座標Z方向
    selectname = ui->comboBox_voxRotateV->currentText();


    ui->lightPosXSpin->setValue(lightPosX);
    //ui->lightPosYSpin->setValue(lightPosY);
    ui->lightPosZSpin->setValue(lightPosZ);
}


void Vox3DForm::func_slot_3D_acceptVoxpath(QString inStr)
{
    qDebug() << "[DEBUG]Vox3DSub02.cpp-func_slot_3D_acceptVoxpath";
    ui->lineEdit_voxpath->setText(inStr);
    on_pushButton_voxpathLoad_clicked();
}
