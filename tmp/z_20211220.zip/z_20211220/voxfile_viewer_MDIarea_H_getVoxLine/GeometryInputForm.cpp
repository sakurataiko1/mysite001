#include "GeometryInputForm.h"
#include "ui_GeometryInputForm.h"

GeometryInputForm::GeometryInputForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::GeometryInputForm)
{
    ui->setupUi(this);
    this->setWindowTitle("2Dviewer");
}

GeometryInputForm::~GeometryInputForm()
{
    delete ui;
}
