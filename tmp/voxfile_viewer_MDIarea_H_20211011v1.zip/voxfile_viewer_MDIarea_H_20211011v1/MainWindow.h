#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPointer>

#include <QMdiSubWindow>

//for FTP Download
#include <QProcess>
#include <QtCore/QThread>
#include <QDir>
#include <QFileInfo>
#include <QDateTime>
#include <QRegExp>
#define TR(s) (QString::fromLocal8bit(s)) //2018.09.12 日本語表示

#include <QWidget>

//QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
//QT_END_NAMESPACE

class Vox3DForm;
class Zsub2Form;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    Ui::MainWindow *ui;

    //QPointer<Zsub2Form> mZsub2Form;
    QMdiSubWindow *SubWindowZsub2Form;

    //QPointer<Vox3DForm> mVox3DForm;
    QMdiSubWindow *SubWindowVox3DForm;
};
#endif // MAINWINDOW_H
