#include "CommonSubClass.h"

CommonSubClass::CommonSubClass()
{

}
