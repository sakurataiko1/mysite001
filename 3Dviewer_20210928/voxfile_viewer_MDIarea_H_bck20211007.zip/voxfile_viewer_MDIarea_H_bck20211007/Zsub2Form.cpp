#include "Zsub2Form.h"
#include "ui_Zsub2Form.h"

Zsub2Form::Zsub2Form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Zsub2Form)
{
    ui->setupUi(this);
}

Zsub2Form::~Zsub2Form()
{
    delete ui;
}
