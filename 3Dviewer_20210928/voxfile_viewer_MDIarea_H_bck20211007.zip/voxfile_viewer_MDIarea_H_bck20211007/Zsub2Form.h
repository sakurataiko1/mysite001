#ifndef ZSUB2FORM_H
#define ZSUB2FORM_H

#include <QWidget>

namespace Ui {
class Zsub2Form;
}

class Zsub2Form : public QWidget
{
    Q_OBJECT

public:
    explicit Zsub2Form(QWidget *parent = nullptr);
    ~Zsub2Form();

private:
    Ui::Zsub2Form *ui;
};

#endif // ZSUB2FORM_H
